package data.console.commands;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import static data.scripts.RCSecondWavePlugin.RCSWgetRemnantSystems;
import java.util.HashMap;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;

public class FindRemnantSystems implements BaseCommand {

    @Override
    public BaseCommand.CommandResult runCommand(String args, BaseCommand.CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return BaseCommand.CommandResult.WRONG_CONTEXT;
        }
        
        HashMap<LocationAPI, String> RCSW_RemnantSystems = RCSWgetRemnantSystems();
        
        if ("low".equals(args) || "Low".equals(args) || "yellow".equals(args) || "Yellow".equals(args)) {
            for (LocationAPI system : RCSW_RemnantSystems.keySet()) {
                if (RCSW_RemnantSystems.get(system).equals("Low")) {
                    Console.showMessage(system + ", located at: "+ system.getLocation());
                }
            }
        }
        else if ("medium".equals(args) || "Medium".equals(args) || "med".equals(args) || "Med".equals(args) || "orange".equals(args) || "Orange".equals(args)) {
            for (LocationAPI system : RCSW_RemnantSystems.keySet()) {
                if (RCSW_RemnantSystems.get(system).equals("Medium")) {
                    Console.showMessage(system + ", located at: "+ system.getLocation());
                }
            }
        }
        else if ("high".equals(args) || "High".equals(args) || "red".equals(args) || "Red".equals(args)) {
            for (LocationAPI system : RCSW_RemnantSystems.keySet()) {
                if (RCSW_RemnantSystems.get(system).equals("High")) {
                    Console.showMessage(system + ", located at: "+ system.getLocation());
                }
            }
        }
        else {
            for (LocationAPI system : RCSW_RemnantSystems.keySet()) {
                if (!RCSW_RemnantSystems.get(system).equals("Secondary")) {
                    Console.showMessage(RCSW_RemnantSystems.get(system)+": " + system + ", located at: "+ system.getLocation());
                }
            }
        }
        Console.showMessage("Note: Player location is: " + Global.getSector().getPlayerFleet().getLocationInHyperspace());
        return BaseCommand.CommandResult.SUCCESS;   
    }
}
