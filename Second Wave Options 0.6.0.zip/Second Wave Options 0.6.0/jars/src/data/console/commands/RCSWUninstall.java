package data.console.commands;

import com.fs.starfarer.api.Global;
import data.scripts.ApplyRCSWChanges;
import data.scripts.RCSecondWavePlugin;
import org.lazywizard.console.Console;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;

public class RCSWUninstall implements BaseCommand {
    
    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
        
        if (Global.getSector().hasScript(ApplyRCSWChanges.class)) {
            RCSecondWavePlugin.RCSW_UNINSTALL = true;    
            Console.showMessage("RC's Second Wave Options uninstalled. Most changes should be removed immediately - you may continue playing. Be sure to uncheck this mod next time you restart Starsector.");
            Console.showMessage("CAUTION: You will need to reuse this command if you reload this save with the mod still enabled.");
            Console.showMessage("NOTE: Removing overwritten variants will require you to uncheeck the mod.");
            return CommandResult.SUCCESS;
        } else {
            Console.showMessage("RC's Second Wave Options is currently not active.");
            return CommandResult.WRONG_CONTEXT;
        }
    }
}
