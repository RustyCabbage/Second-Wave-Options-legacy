package data.console.commands;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import data.scripts.AddHullMod;
import data.scripts.ApplyRCSWChanges;
import data.scripts.ApplyRCSWChangesTime;
import data.scripts.DoctrineEvolution;
import data.scripts.RCSecondWavePlugin;
import static data.scripts.RCSecondWavePlugin.DOCTRINE_EVOLUTION;
import static data.scripts.RCSecondWavePlugin.HULL_MOD;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;

public class RCSWReloadSettings implements BaseCommand {    
    
    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
        
        try {
            //Reset to original before reloading settings
            if (DOCTRINE_EVOLUTION) {
                for (FactionAPI faction : Global.getSector().getAllFactions()) {
                    new DoctrineEvolution().DoctrineReturnToOriginal(faction);
                }                
                new DoctrineEvolution().DoctrineSetup();
                Console.showMessage("Doctrine Evolution setup completed. Faction Doctrine updated.");
            }
            if (HULL_MOD) {
                new AddHullMod().hullModCleanup();
                Console.showMessage("Reduced salvage hullmod cleaned up.");
            }
            //Reload settings
            RCSecondWavePlugin.loadRCSWSettings();
            Console.showMessage("RC's Second Wave Options settings reloaded.");
        } catch (IOException ex) {
            Logger.getLogger(RCSWReloadSettings.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(RCSWReloadSettings.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (Global.getSector().hasScript(ApplyRCSWChanges.class) || Global.getSector().hasScript(ApplyRCSWChangesTime.class)) {        
            RCSecondWavePlugin.RCSW_RELOAD = true;
            ApplyRCSWChangesTime.deMonthlyIntervalCheck = 69f;
        } else {
            Console.showMessage("Note: RC's Second Wave Options is not currently active.");
        }
        return CommandResult.SUCCESS;
    }
}