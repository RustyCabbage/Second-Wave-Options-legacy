package data.console.commands;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.ApplyRCSWChangesTime;
import data.scripts.DoctrineEvolution;
import data.scripts.RCSecondWavePlugin;
import static data.scripts.RCSecondWavePlugin.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;

public class RCSWGetMarketScores implements BaseCommand {      
        
    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        List<String> hiddenMarketFactions = RCSecondWavePlugin.getRaiderFactions(); 
        
        List<String> ids = new ArrayList<String>();
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            ids.add(faction.getId());
        }
        
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
        
        if (!Global.getSector().hasScript(ApplyRCSWChangesTime.class)) {        
            Console.showMessage("RC's Second Wave Options is currently not active.");
            return CommandResult.WRONG_CONTEXT;
        }
        
        if ("vanilla".equals(args)) {
            List<String> vanillaFactionsWithMarkets = new ArrayList<String>();
                vanillaFactionsWithMarkets.add("hegemony");
                vanillaFactionsWithMarkets.add("persean");
                vanillaFactionsWithMarkets.add("luddic_church");
                vanillaFactionsWithMarkets.add("sindrian_diktat");
                vanillaFactionsWithMarkets.add("tritachyon");
                vanillaFactionsWithMarkets.add("independent");
                vanillaFactionsWithMarkets.add("pirates");
                vanillaFactionsWithMarkets.add("luddic_path");
                
            if (DOCTRINE_EVOLUTION && de_USE_MARKET_BONUS) {                  
                for (String factionId : vanillaFactionsWithMarkets) {
                    FactionAPI faction = Global.getSector().getFaction(factionId);
                    
                    float MarketScores[];
                    MarketScores = new DoctrineEvolution().getMarketScores(faction);                    
                    
                    float MarketScoresAdj[];
                    MarketScoresAdj = new DoctrineEvolution().getMarketScoresAdj(faction);
                    
                    float marketPoints = 0;
                    marketPoints = new DoctrineEvolution().getMarketPoints(faction);
                    
                    if (hiddenMarketFactions.contains(faction.getId())) {
                        marketPoints = marketPoints * de_RAIDER_FACTION_MULT;
                    }
                    
                    Console.showMessage("For faction '"+factionId+"':");
                    Console.showMessage("Market Scores are: " + Arrays.toString(MarketScores));
                    Console.showMessage("Adjusted market Scores are: " + Arrays.toString(MarketScoresAdj));
                    Console.showMessage("Market Points total is: " + marketPoints);
                    Console.showMessage("-------------------------");
                }
                if (de_USE_LEVEL_SCALING) {
                    int charLevel = Global.getSector().getPlayerStats().getLevel();
                    float levelEffect = (Math.min(charLevel,50)-de_BASE_LEVEL_FOR_SCALING)*de_EFFECT_PER_LEVEL;
                    Console.showMessage("NOTE: All market points are adjusted by "+levelEffect+"% due to level scaling.");
                }
                return CommandResult.SUCCESS;
            } else {
                Console.showMessage("Doctrine Evolution / Market bonuses are currently not active.");
                return CommandResult.WRONG_CONTEXT;
            }
        }
        
        if ("mod".equals(args)) {
            boolean atLeastOne = false;
            if (DOCTRINE_EVOLUTION && de_USE_MARKET_BONUS) {               
                for (FactionAPI faction : Global.getSector().getAllFactions()) {
                    String id = faction.getId();
                    if (RCSW_VanillaFactions.contains(id) || Misc.getFactionMarkets(faction).isEmpty() || "player".equals(id)) {}
                    else {
                        atLeastOne = true;
                        
                        float MarketScores[];
                        MarketScores = new DoctrineEvolution().getMarketScores(faction);                    

                        float MarketScoresAdj[];
                        MarketScoresAdj = new DoctrineEvolution().getMarketScoresAdj(faction);

                        float marketPoints = 0;
                        marketPoints = new DoctrineEvolution().getMarketPoints(faction);

                        if (hiddenMarketFactions.contains(faction.getId())) {
                            marketPoints = marketPoints * de_RAIDER_FACTION_MULT;
                        }

                        Console.showMessage("For faction '"+id+"':");
                        Console.showMessage("Market Scores are: " + Arrays.toString(MarketScores));
                        Console.showMessage("Adjusted market Scores are: " + Arrays.toString(MarketScoresAdj));
                        Console.showMessage("Market Points total is: " + marketPoints);
                        Console.showMessage("-------------------------");
                    }
                }                
                if (atLeastOne) {
                    if (de_USE_LEVEL_SCALING) {
                        int charLevel = Global.getSector().getPlayerStats().getLevel();
                        float levelEffect = (Math.min(charLevel,50)-de_BASE_LEVEL_FOR_SCALING)*de_EFFECT_PER_LEVEL;
                        Console.showMessage("NOTE: All market points are adjusted by "+levelEffect+"% due to level scaling.");
                    }
                    return CommandResult.SUCCESS;
                } else {
                    Console.showMessage("No valid mod factions found.");
                    return CommandResult.SUCCESS;
                }
            } else {
                Console.showMessage("Doctrine Evolution / Market bonuses are currently not active.");
                return CommandResult.WRONG_CONTEXT;
            }
        }
        
        if ("all".equals(args)) {
           if (DOCTRINE_EVOLUTION && de_USE_MARKET_BONUS) {
                for (FactionAPI faction : Global.getSector().getAllFactions()) {
                    String id = faction.getId();        
                    if (Misc.getFactionMarkets(faction).isEmpty() || "player".equals(id)) {}
                    else {
                        float MarketScores[];
                        MarketScores = new DoctrineEvolution().getMarketScores(faction);                    

                        float MarketScoresAdj[];
                        MarketScoresAdj = new DoctrineEvolution().getMarketScoresAdj(faction);

                        float marketPoints = 0;
                        marketPoints = new DoctrineEvolution().getMarketPoints(faction);

                        if (hiddenMarketFactions.contains(faction.getId())) {
                            marketPoints = marketPoints * de_RAIDER_FACTION_MULT;
                        }

                        Console.showMessage("For faction '"+id+"':");
                        Console.showMessage("Market Scores are: " + Arrays.toString(MarketScores));
                        Console.showMessage("Adjusted market Scores are: " + Arrays.toString(MarketScoresAdj));
                        Console.showMessage("Market Points total is: " + marketPoints);
                        Console.showMessage("-------------------------");
                    }
                }
                if (de_USE_LEVEL_SCALING) {
                    int charLevel = Global.getSector().getPlayerStats().getLevel();
                    float levelEffect = (Math.min(charLevel,50)-de_BASE_LEVEL_FOR_SCALING)*de_EFFECT_PER_LEVEL;
                    Console.showMessage("NOTE: All market points are adjusted by "+levelEffect+"% due to level scaling.");
                }
                return CommandResult.SUCCESS;
            } else {
                Console.showMessage("Doctrine Evolution / Market bonuses are currently not active.");
                return CommandResult.WRONG_CONTEXT;
            }
        }
        
        else if (!ids.contains(args)) {
//            Console.showMessage("Faction not recognized or is not in this game.");
            return CommandResult.BAD_SYNTAX;
        }
        
        if (DOCTRINE_EVOLUTION && de_USE_MARKET_BONUS) {
            if ((!de_AFFECT_MOD_FACTIONS && !RCSW_VanillaFactions.contains(args)) || "player".equals(args)) {
                Console.showMessage("Player or mod faction provided when such factions are not affected by Doctrine Evolution.");
                return CommandResult.WRONG_CONTEXT;
            } else {
                FactionAPI faction = Global.getSector().getFaction(args);
                
                float MarketScores[];
                MarketScores = new DoctrineEvolution().getMarketScores(faction);                    

                float MarketScoresAdj[];
                MarketScoresAdj = new DoctrineEvolution().getMarketScoresAdj(faction);

                float marketPoints = 0;
                marketPoints = new DoctrineEvolution().getMarketPoints(faction);

                if (hiddenMarketFactions.contains(faction.getId())) {
                    marketPoints = marketPoints * de_RAIDER_FACTION_MULT;
                }

                Console.showMessage("For faction '"+args+"':");
                Console.showMessage("Market Scores are: " + Arrays.toString(MarketScores));
                Console.showMessage("Adjusted market Scores are: " + Arrays.toString(MarketScoresAdj));
                Console.showMessage("Market Points total is: " + marketPoints);
                if (de_USE_LEVEL_SCALING) {
                    int charLevel = Global.getSector().getPlayerStats().getLevel();
                    float levelEffect = (Math.min(charLevel,50)-de_BASE_LEVEL_FOR_SCALING)*de_EFFECT_PER_LEVEL;
                    Console.showMessage("NOTE: market points are adjusted by "+levelEffect+"% due to level scaling.");
                }
                Console.showMessage("-------------------------");
                return CommandResult.SUCCESS;
            }
        } else {
            Console.showMessage("Doctrine Evolution / Market bonuses are currently not active.");
            return CommandResult.WRONG_CONTEXT;
        }
    }
    
}
