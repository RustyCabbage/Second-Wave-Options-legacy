package data.console.commands;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.ApplyRCSWChanges;
import data.scripts.ApplyRCSWChangesTime;
import static data.scripts.RCSecondWavePlugin.DOCTRINE_EVOLUTION;
import static data.scripts.RCSecondWavePlugin.de_ALLOW_NEGATIVE_TIME_POINTS;
import static data.scripts.RCSecondWavePlugin.de_BASE_LEVEL_FOR_SCALING;
import static data.scripts.RCSecondWavePlugin.de_EFFECT_PER_LEVEL;
import static data.scripts.RCSecondWavePlugin.de_FLAT_BONUS_POINTS;
import static data.scripts.RCSecondWavePlugin.de_MARKET_INCR_PER_CYCLE;
import static data.scripts.RCSecondWavePlugin.de_MARKET_INCR_PER_MARKET;
import static data.scripts.RCSecondWavePlugin.de_MARKET_SCORE_MULT;
import static data.scripts.RCSecondWavePlugin.de_POINTS_PER_CYCLE;
import static data.scripts.RCSecondWavePlugin.de_REMNANT_TIME_BONUS;
import static data.scripts.RCSecondWavePlugin.de_TIME_BONUS_START_YEAR;
import static data.scripts.RCSecondWavePlugin.de_USE_FLAT_BONUS;
import static data.scripts.RCSecondWavePlugin.de_USE_LEVEL_SCALING;
import static data.scripts.RCSecondWavePlugin.de_USE_MARKET_BONUS;
import static data.scripts.RCSecondWavePlugin.de_USE_TIME_BONUS;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;

public class RCSWForceDoctrineUpdate implements BaseCommand {

    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
        
        if (!Global.getSector().hasScript(ApplyRCSWChanges.class)) {        
            Console.showMessage("RC's Second Wave Options is currently not active.");
            return CommandResult.WRONG_CONTEXT;
        }
        
        if (DOCTRINE_EVOLUTION) {
            ApplyRCSWChangesTime.deMonthlyIntervalCheck = 69f;
            Console.showMessage("Doctrines will be updated upon leaving this menu.");
            if ("debug".equals(args)) {
                int cyclesPassed = 0;
                if (de_USE_FLAT_BONUS) {
                    Console.showMessage("Flat bonus is: " + de_FLAT_BONUS_POINTS);
                }
                if (de_USE_TIME_BONUS) {
                    cyclesPassed = Math.round(Global.getSector().getClock().getCycle() - de_TIME_BONUS_START_YEAR);
                    float timePoints = 0;
                    if (de_ALLOW_NEGATIVE_TIME_POINTS) {
                        timePoints = (float) cyclesPassed * de_POINTS_PER_CYCLE;
                    } else {
                        timePoints = (float) Math.max(0,cyclesPassed * de_POINTS_PER_CYCLE);
                    }
                    Console.showMessage("Time bonus is: " + timePoints);
                    Console.showMessage("Time bonus for remnants are: " + Math.max(0,timePoints * de_REMNANT_TIME_BONUS));
                }
                if (de_USE_MARKET_BONUS) {
                    cyclesPassed = Global.getSector().getClock().getCycle() - 206;
                    FactionAPI playerFaction = Global.getSector().getFaction("player");

                    float MarketScoreMult = de_MARKET_SCORE_MULT;
                    MarketScoreMult *= (1+de_MARKET_INCR_PER_CYCLE*cyclesPassed);
                    MarketScoreMult *= (1+de_MARKET_INCR_PER_MARKET * Misc.getFactionMarkets(playerFaction).size());
                    Console.showMessage("Market Score Mult is: " + MarketScoreMult);
                }
                if (de_USE_LEVEL_SCALING) {
                    int charLevel = Global.getSector().getPlayerStats().getLevel();
                    float levelEffect = (charLevel-de_BASE_LEVEL_FOR_SCALING)*de_EFFECT_PER_LEVEL;
                    Console.showMessage("Level Effect is: "+levelEffect+"%");
                }
            }
            return CommandResult.SUCCESS;
        } else {
            Console.showMessage("Doctrine Evolution is currently not active.");
            return CommandResult.WRONG_CONTEXT;
        }
    }
    
}
