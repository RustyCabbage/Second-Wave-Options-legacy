package data.console.commands;

import data.scripts.RCSecondWavePlugin;
import static data.scripts.RCSecondWavePlugin.SECURE_MARKETS_NEW_GAME;
import data.scripts.SecureMarkets;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;

/*
Test using:
runcode Console.showMessage(Global.getSector().getEconomy().getMarket("kanni").getIndustries());
Console.showMessage(Global.getSector().getEconomy().getMarket("nomios").getIndustries());

    TODO:
-add arguments for patrol HQ, bases, stations
*/

public class RCSWApplySecureMarkets implements BaseCommand {

    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
/*        
        if ("0".equals(args)) {
            RCSecondWavePlugin.sm_ADD_PATROL_HQ = 0;
        }
        else if ("1".equals(args)) {
            RCSecondWavePlugin.sm_ADD_PATROL_HQ = 1;
        }
        else if ("2".equals(args)) {
            RCSecondWavePlugin.sm_ADD_PATROL_HQ = 2;
        }
*/        
        SECURE_MARKETS_NEW_GAME = true;
        new SecureMarkets().AddMarketDefenses();
        Console.showMessage("RC's Second Wave Options: Secure Markets settings added.");
        if (RCSecondWavePlugin.sm_ADD_MILITARY_BASE == 1) {
            Console.showMessage("Military Bases/High Commands added for all non-pirate/LP markets of size "+
                    RCSecondWavePlugin.sm_SIZE_FOR_MILITARY_BASE+"/"+RCSecondWavePlugin.sm_SIZE_FOR_HIGH_COMMAND+".");
        } else if (RCSecondWavePlugin.sm_ADD_MILITARY_BASE == 2) {
            Console.showMessage("Military Bases/High Commands added for all markets of size "+
                    RCSecondWavePlugin.sm_SIZE_FOR_MILITARY_BASE+"/"+RCSecondWavePlugin.sm_SIZE_FOR_HIGH_COMMAND+".");
        } else {
            Console.showMessage("No Military Bases/High Commands added.");
        }
        if (RCSecondWavePlugin.sm_ADD_PATROL_HQ == 1) {
            Console.showMessage("Patrol HQs added for all non-pirate/LP markets.");
        } else if (RCSecondWavePlugin.sm_ADD_PATROL_HQ == 2) {
            Console.showMessage("Patrol HQs added for all markets.");
        } else {
            Console.showMessage("No Patrol HQs added.");
        }
        if (RCSecondWavePlugin.sm_ADD_STATIONS == 1) {
            Console.showMessage("Tier 1/2/3 Stations added for all non-pirate/LP markets of size "+
                    RCSecondWavePlugin.sm_SIZE_FOR_ORBITAL_STATION+"/"+RCSecondWavePlugin.sm_SIZE_FOR_BATTLE_STATION+"/"+RCSecondWavePlugin.sm_SIZE_FOR_STAR_FORTRESS+".");
        } else if (RCSecondWavePlugin.sm_ADD_STATIONS == 2) {
            Console.showMessage("Tier 1/2/3 Stations added for all markets of size "+
                    RCSecondWavePlugin.sm_SIZE_FOR_ORBITAL_STATION+"/"+RCSecondWavePlugin.sm_SIZE_FOR_BATTLE_STATION+"/"+RCSecondWavePlugin.sm_SIZE_FOR_STAR_FORTRESS+".");
        } else {
            Console.showMessage("No Stations added.");
        }
        return CommandResult.SUCCESS;   
    }
}
