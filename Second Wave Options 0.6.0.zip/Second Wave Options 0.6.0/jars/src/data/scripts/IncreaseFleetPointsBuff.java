
package data.scripts;

import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

/*
    TODO:
*/
        
public class IncreaseFleetPointsBuff implements Buff {
    private String id;
    private float dur;
    
    public IncreaseFleetPointsBuff(String id, float dur) {
        this.id = id;
        this.dur = dur;
    }    

    @Override
    public void apply(FleetMemberAPI member) {
    }

    @Override
    public String getId() {
        return id;
    }
    @Override
    public boolean isExpired() {
        return dur <= 0;
    }

    public float getDur() {
        return dur;
    }
    
    public void setDur(float dur) {
        this.dur = dur;
    }
    
    @Override
    public void advance(float days) {
        setDur(dur);
    }
}