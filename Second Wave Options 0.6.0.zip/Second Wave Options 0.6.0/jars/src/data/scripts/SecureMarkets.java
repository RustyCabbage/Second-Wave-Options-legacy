package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.util.Misc;
import static data.scripts.ApplyRCSWChangesTime.log;
import static data.scripts.RCSecondWavePlugin.RCSW_VanillaFactions;
import static data.scripts.RCSecondWavePlugin.de_ALLOW_NEGATIVE_MARKET_POINTS;
import static data.scripts.RCSecondWavePlugin.de_HEAVY_INDUSTRY_MULT;
import static data.scripts.RCSecondWavePlugin.de_HIDDEN_MARKET_MULT;
import static data.scripts.RCSecondWavePlugin.de_HIGH_COMMAND_MULT;
import static data.scripts.RCSecondWavePlugin.de_MILITARY_BASE_MULT;
import static data.scripts.RCSecondWavePlugin.de_ORBITAL_WORKS_MULT;
import static data.scripts.RCSecondWavePlugin.sm_ADD_GROUND_DEFENSES;
import static data.scripts.RCSecondWavePlugin.sm_ADD_MILITARY_BASE;
import static data.scripts.RCSecondWavePlugin.sm_ADD_PATROL_HQ;
import static data.scripts.RCSecondWavePlugin.sm_ADD_PLANETARY_SHIELD;
import static data.scripts.RCSecondWavePlugin.sm_ADD_STATIONS;
import static data.scripts.RCSecondWavePlugin.sm_AFFECT_MOD_FACTIONS;
import static data.scripts.RCSecondWavePlugin.sm_SIZE_FOR_BATTLE_STATION;
import static data.scripts.RCSecondWavePlugin.sm_SIZE_FOR_HEAVY_BATTERIES;
import static data.scripts.RCSecondWavePlugin.sm_SIZE_FOR_HIGH_COMMAND;
import static data.scripts.RCSecondWavePlugin.sm_SIZE_FOR_MILITARY_BASE;
import static data.scripts.RCSecondWavePlugin.sm_SIZE_FOR_ORBITAL_STATION;
import static data.scripts.RCSecondWavePlugin.sm_SCORE_FOR_SHIELD;
import static data.scripts.RCSecondWavePlugin.sm_SIZE_FOR_STAR_FORTRESS;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/*
    TODO:    
-Refine add station mechanics (e.g. improving based on market size)
-why the heck is this all in one method, you maniac?
-make a proper blacklist.
*/

public class SecureMarkets {

/*
    public HashMap<String, String> getStationHashMap() {
        HashMap<String, String> StationHashMap = new HashMap<String, String>();
        StationHashMap.put("orbitalstation", "orbitalstation");
        StationHashMap.put("orbitalstation_mid", "orbitalstation");
        StationHashMap.put("orbitalstation_high", "orbitalstation");
        StationHashMap.put("battlestation", "battlestation");
        StationHashMap.put("battlestation_mid", "battlestation");
        StationHashMap.put("battlestation_high", "battlestation");
        StationHashMap.put("starfortress", "starfortress");
        StationHashMap.put("starfortress_mid", "starfortress");
        StationHashMap.put("starfortress_high", "starfortress");
        return StationHashMap;
    }
*/
    
    public List<String> getStationList() {
        List<String> StationList = new ArrayList<String>();
            StationList.add("orbitalstation");
            StationList.add("orbitalstation_mid");
            StationList.add("orbitalstation_high");
            StationList.add("battlestation");
            StationList.add("battlestation_mid");
            StationList.add("battlestation_high");
            StationList.add("starfortress");
            StationList.add("starfortress_mid");
            StationList.add("starfortress_high");
        return StationList;
    }
    
    public List<String> getBlacklistedFactions() {
        List<String> blacklistedFactions = new ArrayList<String>();
            blacklistedFactions.add("player");
            blacklistedFactions.add("neutral");
            blacklistedFactions.add("mayasura");
        return blacklistedFactions;
    }
    
    public List<String> getBlacklistedMarkets() {
        List<String> blacklistedMarkets = new ArrayList<String>();
        if (Global.getSettings().getModManager().isModEnabled("mayasura")) {
            blacklistedMarkets.add("mairaath");
        }
        return blacklistedMarkets;
    }
    
    public void AddMarketDefenses() {
        List<String> RCSW_RaiderFactions = RCSecondWavePlugin.getRaiderFactions();
        List<String> blacklistedFactions = getBlacklistedFactions();
        List<String> blacklistedMarkets = getBlacklistedMarkets();

        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            String id = market.getId();
            String faction = market.getFaction().getId();
            int size = market.getSize();
            if ((!sm_AFFECT_MOD_FACTIONS && !RCSW_VanillaFactions.contains(faction)) || blacklistedFactions.contains(faction) || blacklistedMarkets.contains(id)) {}
            else {
                if (sm_ADD_GROUND_DEFENSES) {
                    if (size >= sm_SIZE_FOR_HEAVY_BATTERIES && !market.hasIndustry("heavybatteries")) {
                        if (market.hasIndustry("grounddefenses")) {
                            market.removeIndustry("grounddefenses", null, false);
                        }
                        market.addIndustry("heavybatteries");
                    }
                    if (size < sm_SIZE_FOR_HEAVY_BATTERIES &&
                            !market.hasIndustry("grounddefenses") && !market.hasIndustry("heavybatteries")) {
                        market.addIndustry("grounddefenses");
                    }         
                }
                if (sm_ADD_MILITARY_BASE == 1 || sm_ADD_MILITARY_BASE == 2) {
                    if (sm_ADD_MILITARY_BASE == 1 && RCSW_RaiderFactions.contains(faction)) {}
                    else if (Misc.getMaxIndustries(market) > Misc.getNumIndustries(market)) {
                        if (size >= sm_SIZE_FOR_HIGH_COMMAND && !market.hasIndustry("highcommand")) {
                            if (market.hasIndustry("militarybase")) {
                                market.removeIndustry("militarybase", null, false);
                            }
                            if (market.hasIndustry("patrolhq")) {
                                market.removeIndustry("patrolhq", null, false);
                            }
                            market.addIndustry("highcommand");
                        } else if (size > sm_SIZE_FOR_MILITARY_BASE && !market.hasIndustry("militarybase")) {
                            if (market.hasIndustry("patrolhq")) {
                                market.removeIndustry("patrolhq", null, false);
                            }
                            market.addIndustry("militarybase");
                        }
                    }
                }
                if (sm_ADD_PATROL_HQ == 1 || sm_ADD_PATROL_HQ == 2) {
                    if (sm_ADD_PATROL_HQ == 1 && RCSW_RaiderFactions.contains(faction)) {}
                    else if (!market.hasIndustry("patrolhq") && !market.hasIndustry("militarybase") && !market.hasIndustry("highcommand")) {
                        market.addIndustry("patrolhq");
                    }
                }
                if (sm_ADD_STATIONS == 1 || sm_ADD_STATIONS == 2) {
                    List<String> StationList = getStationList();
                    Random random = new Random();
                    int type;
                    if (sm_ADD_STATIONS == 1 && RCSW_RaiderFactions.contains(faction)) {}
                    else {
                        if (Misc.getStationIndustry(market) == null) {
                            if (size >= sm_SIZE_FOR_STAR_FORTRESS) {
                                type = random.nextInt(3);
                                market.addIndustry((String) StationList.get(6+type));
                            } else if (size >= sm_SIZE_FOR_BATTLE_STATION) {
                                type = random.nextInt(3);
                                market.addIndustry((String) StationList.get(3+type));
                            } else if (size >= sm_SIZE_FOR_ORBITAL_STATION) {
                                type = random.nextInt(3);
                                market.addIndustry((String) StationList.get(type));
                            }
                        }
                    }
                }
                market.reapplyIndustries();
            }
        }
    }
    
    public List<MarketAPI> FindBestMarkets(FactionAPI faction) {
        float bestMarketScore = sm_SCORE_FOR_SHIELD;
        List<MarketAPI> bestMarketList = new ArrayList<MarketAPI>();
        
        float MarketScores[];
        MarketScores = new float [Misc.getFactionMarkets(faction).size()];
        
        int j=0;
        for (MarketAPI factionMarket : Misc.getFactionMarkets(faction)) {
            float size = factionMarket.getSize();
            float stab = factionMarket.getStabilityValue();
            if (de_ALLOW_NEGATIVE_MARKET_POINTS) {
                MarketScores[j] = size*size * (stab-5)/5;
            } else {
                MarketScores[j] = size*size * stab/10;
            }
            //hidden markets get reduced scores
            if (factionMarket.isHidden()) {
                MarketScores[j] *= de_HIDDEN_MARKET_MULT;
            }
            if (factionMarket.hasIndustry("militarybase")) {
                MarketScores[j] *= de_MILITARY_BASE_MULT;
            }
            if (factionMarket.hasIndustry("highcommand")) {
                MarketScores[j] *= de_HIGH_COMMAND_MULT;
            }
            if (factionMarket.hasIndustry("heavyindustry")) {
                MarketScores[j] *= de_HEAVY_INDUSTRY_MULT;
            }
            if (factionMarket.hasIndustry("orbitalworks")) {
                MarketScores[j] *= de_ORBITAL_WORKS_MULT;
            }
            //if the new market score is higher, clear list and then add to list
            if (MarketScores[j] > bestMarketScore) {
                bestMarketScore = MarketScores[j];
                bestMarketList.clear();
                bestMarketList.add(factionMarket);
            }
            //if the new market score is the same, add to list
            else if (MarketScores[j] == bestMarketScore) {
                bestMarketList.add(factionMarket);
            }
            j++;
        }
        return bestMarketList;
    }
    
    public void AddPlanetaryShield(MarketAPI market) {
        if (market == null) {
            log.info("Secure Markets: Invalid market for planetary shield.");
            return;
        }
        List<String> RCSW_RaiderFactions = RCSecondWavePlugin.getRaiderFactions();
        String faction = market.getFaction().getId();
        if ((!sm_AFFECT_MOD_FACTIONS && !RCSW_VanillaFactions.contains(faction)) || "player".equals(faction) || "neutral".equals(faction)) {}
        else if (sm_ADD_PLANETARY_SHIELD == 1 || sm_ADD_PLANETARY_SHIELD == 2) {
            if (sm_ADD_PLANETARY_SHIELD == 1 && RCSW_RaiderFactions.contains(faction)) {}
            else if (!market.hasIndustry("planetaryshield")) {
                market.addIndustry("planetaryshield");
                log.info("Secure Markets: Planetary Shield added for "+faction+" at: "+market.getName());
                market.reapplyIndustries();
            }
        }
    }
    
}
