package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import static data.scripts.RCSecondWavePlugin.iliTimeUnsafe;
import static data.scripts.RCSecondWavePlugin.ili_MIN_REP;
import static data.scripts.RCSecondWavePlugin.iliAlertOnce;
import org.apache.log4j.Logger;

public class RCSWMarketListener extends BaseCampaignEventListener {

    public static Logger log = Global.getLogger(RCSWMarketListener.class);  
    
    public RCSWMarketListener() {
        super(false);
    }

    @Override
    public void reportPlayerOpenedMarket(MarketAPI market)
    {
        // Check if market id matches; if so, do stuff here
        if (Math.round(market.getFaction().getRelationship("player")*100) >= ili_MIN_REP) {
//            iliSafe = true;
            iliAlertOnce = true;
            iliTimeUnsafe = 0f;
//            Global.getSector().getMemoryWithoutUpdate().set("$timeUnsafe", iliTimeUnsafe);
        }
        log.info("RCSW: Market opened.");
    }
}
