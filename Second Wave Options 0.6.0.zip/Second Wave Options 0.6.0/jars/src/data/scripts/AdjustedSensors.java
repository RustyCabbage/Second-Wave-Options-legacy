package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BuffManagerAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.RCSecondWavePlugin.dark_NEG_REP_SENSOR_INCR_MAX;
import static data.scripts.RCSecondWavePlugin.dark_SHIP_PLAYER_ONLY;
import java.util.ArrayList;
import java.util.List;

public class AdjustedSensors {
    public List<CampaignFleetAPI> dsAffectedFleets = new ArrayList<CampaignFleetAPI>();
    LocationAPI currentLoc = Global.getSector().getCurrentLocation();
    
    public boolean adjustedSensorsApplyShips() {
        boolean needsSync = false;
        for (CampaignFleetAPI localFleet : currentLoc.getFleets()) {
            if (dark_SHIP_PLAYER_ONLY) {
                if (!localFleet.isPlayerFleet()) {}
                else {
                    for (FleetMemberAPI member : localFleet.getFleetData().getMembersListCopy()) {
                        String buffID = "darkBuffID";
                        float buffDur = 1f;
                        BuffManagerAPI.Buff test = member.getBuffManager().getBuff(buffID);
                        if (test instanceof DarkSectorBuff) {
                            DarkSectorBuff buff = (DarkSectorBuff) test;
                            buff.setDur(buffDur);
                        } else {
                            member.getBuffManager().addBuff(new DarkSectorBuff(buffID, buffDur));
                            needsSync = true;
                        }
                    }
                    if (!dsAffectedFleets.contains(localFleet)) {
                        dsAffectedFleets.add(localFleet);
                    }
                }
            } else {
                for (FleetMemberAPI member : localFleet.getFleetData().getMembersListCopy()) {
                    String buffID = "darkBuffID";
                    float buffDur = 1f;
                    BuffManagerAPI.Buff test = member.getBuffManager().getBuff(buffID);
                    if (test instanceof DarkSectorBuff) {
                        DarkSectorBuff buff = (DarkSectorBuff) test;
                        buff.setDur(buffDur);
                    } else {
                        member.getBuffManager().addBuff(new DarkSectorBuff(buffID, buffDur));
                        needsSync = true;
                    }
                }
                if (!dsAffectedFleets.contains(localFleet)) {
                    dsAffectedFleets.add(localFleet);
                }
            }
        }
        return needsSync;
    }
    
    public void adjustedSensorsApplyFleets() {
/*
        IntervalUtil refresh = new IntervalUtil(10f,10f);
        refresh.advance(amount);
        if (refresh.intervalElapsed()) {
*/
            for (CampaignFleetAPI localFleet : currentLoc.getFleets()) {
                if (!localFleet.isPlayerFleet()) {
                    if (localFleet.getStats().getSensorStrengthMod().getPercentBonuses().containsKey("darkBuffID")) {
                        localFleet.getStats().getSensorStrengthMod().unmodifyPercent("darkBuffID");
                    }
                    //rep is a decimal value: e.g. -11 = -0.11
                    int rep = Math.round(localFleet.getFaction().getRelationship("player"));
                    if (rep < 0 && localFleet.getStats().getSensorStrengthMod().getPercentBonuses().containsKey("darkBuffID")) {
                        float enemySensorStrPercent = (float) Math.abs(rep * dark_NEG_REP_SENSOR_INCR_MAX);
                        localFleet.getStats().getSensorStrengthMod().modifyPercent("darkBuffID", enemySensorStrPercent, "Adjusted Sensors");
                    }
                }
                if (!dsAffectedFleets.contains(localFleet)) {
                    dsAffectedFleets.add(localFleet);
                }
            }
//        }
    }        
    
    public void adjustedSensorsCleanup() {
/*
            for (CampaignFleetAPI localFleet : currentLoc.getFleets()) {
                for (FleetMemberAPI member : localFleet.getFleetData().getMembersListCopy()) {
                    Buff darkBuff = member.getBuffManager().getBuff("darkBuffID");
                    if (darkBuff instanceof DarkSectorBuff) {
                        member.getBuffManager().removeBuff("darkBuffID");
                        needsSync = true;
                    }
                }
            }
            if (Global.getSector().getPlayerFleet().getStats().getSensorStrengthMod().getMultBonuses().containsKey("darkBuffID")) {
                Global.getSector().getPlayerFleet().getStats().getSensorStrengthMod().unmodifyMult("darkBuffID");
                Global.getSector().getPlayerFleet().getStats().getSensorProfileMod().unmodifyMult("darkBuffID");
            }

*/
            //Check list of fleets affected by Dark Sector (includes player fleet) and removes all related buffs/mods
            for (CampaignFleetAPI fleet : dsAffectedFleets) {
                fleet.getStats().getSensorStrengthMod().unmodify("darkBuffID");
                fleet.getStats().getSensorProfileMod().unmodify("darkBuffID");
                for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                    BuffManagerAPI.Buff darkBuff = member.getBuffManager().getBuff("darkBuffID");
                    if (darkBuff instanceof DarkSectorBuff) {
                        member.getBuffManager().removeBuff("darkBuffID");
//                        needsSync = true;
                    }
                }
                fleet.forceSync();
            }
            dsAffectedFleets.clear();
    }    
}
