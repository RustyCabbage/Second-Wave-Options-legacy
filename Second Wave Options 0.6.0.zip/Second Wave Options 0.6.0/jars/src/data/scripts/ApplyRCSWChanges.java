package data.scripts;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import data.hullmods.SecondWaveHullMod;
//import static data.scripts.ApplyRCSWChangesTime.deMonthlyIntervalCheck;
import static data.scripts.RCSecondWavePlugin.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

// THIS ONE RUNS WHILE PAUSED

/*
    TODO:
-Consider splitting the uninstall option.
-Find out how to make the DarkSector Fleet Buff tooltip work.
-Clean up these buffs - they don't need a duration...
*/

public class ApplyRCSWChanges implements EveryFrameScript {       

    public static Logger log = Global.getLogger(ApplyRCSWChanges.class);
    public List<CampaignFleetAPI> dsAffectedFleets = new ArrayList<CampaignFleetAPI>();

    AdjustedSensors AS = new AdjustedSensors();
    AddHullMod HM = new AddHullMod();

    float refresh = 0;
    float reapply = 0;
    
    @Override
    public void advance(float amount) {
        
        boolean needsSync = false;
        LocationAPI currentLoc = Global.getSector().getCurrentLocation();
        refresh += Global.getSector().getClock().convertToDays(amount);
        reapply += Global.getSector().getClock().convertToDays(amount);
        
        if (RCSW_UNINSTALL || RCSW_RELOAD) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
                Buff CRBuff = member.getBuffManager().getBuff("CRBuffID");
                if (CRBuff instanceof SlowCRBuff) {
                    member.getBuffManager().removeBuff("CRBuffID");
                    needsSync = true;
                }
                Buff odyBuff = member.getBuffManager().getBuff("odyBuffID");
                if (odyBuff instanceof OdysseyModeBuff) {
                    member.getBuffManager().removeBuff("odyBuffID");
                    needsSync = true;
                }         
            }
            
            AS.adjustedSensorsCleanup();
            
            if (!hm_AFFECTS_PLAYER) {
                HM.removeHullModFromPlayerFleet();
            }            
            HM.hullModCleanup();
            
//            if (DOCTRINE_EVOLUTION) {
                for (FactionAPI faction : Global.getSector().getAllFactions()) {
                    new DoctrineEvolution().DoctrineReturnToOriginal(faction);
                }
//            }

            if (needsSync) {
                Global.getSector().getPlayerFleet().forceSync();
            }

            if (RCSW_RELOAD) {
                RCSW_RELOAD = false;                
            } else {
                Global.getSector().removeScript(this);
            }        
        } else {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
                if (SLOW_CR) {
                    String buffID = "CRBuffID";
                    float buffDur = 1f;
                    Buff test = member.getBuffManager().getBuff(buffID);
                    if (test instanceof SlowCRBuff) {
                        SlowCRBuff buff = (SlowCRBuff) test;
                        buff.setDur(buffDur);
                    } else {
                        member.getBuffManager().addBuff(new SlowCRBuff(buffID, buffDur));
                        needsSync = true;
                    }
                }
                if (ODYSSEY_MODE) {
                    String buffID = "odyBuffID";
                    float buffDur = 1f;
                    Buff test = member.getBuffManager().getBuff(buffID);
                    if (test instanceof OdysseyModeBuff) {
                        OdysseyModeBuff buff = (OdysseyModeBuff) test;
                        buff.setDur(buffDur);
                        needsSync = true;
                    } else {
                        member.getBuffManager().addBuff(new OdysseyModeBuff(buffID, buffDur));
                        needsSync = true;
                    }
                }
            }
            if (DARK_SECTOR) {
                if (AS.adjustedSensorsApplyShips()) {
                    needsSync = true;
                }
                if (refresh > 1) {
                    AS.adjustedSensorsApplyFleets();
                    log.info("Applying Adjusted Sensors.");
                }
                if (!Global.getSector().getPlayerFleet().getStats().getSensorStrengthMod().getMultBonuses().containsKey("darkBuffID")) {
                    Global.getSector().getPlayerFleet().getStats().getSensorStrengthMod().modifyMult("darkBuffID", dark_FLEET_SENSOR_STR_MULT, "Dark Sector");
                    Global.getSector().getPlayerFleet().getStats().getSensorProfileMod().modifyMult("darkBuffID", dark_FLEET_SENSOR_PRO_MULT, "Dark Sector");
                }
            }

            if (needsSync) {
                Global.getSector().getPlayerFleet().forceSync();
            }
            
            if (HULL_MOD) {
                if (reapply > 0.1 && refresh < 1) {
                    HM.addHullModToShips();
                }
                if (refresh > 1) {
                    HM.hullModCleanup();
                    HM.addHullModToShips();                    
                }
            }
        }
        if (reapply > 0.1) {
            reapply = 0;
        }
        if (refresh > 1) {
            refresh = 0;
        }        
    }    
    @Override
     public boolean isDone() {
        return false;
    }
    @Override
    public boolean runWhilePaused() {
        return true;
    }

}