package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.RCSecondWavePlugin.ILIAD_MODE;
import static data.scripts.RCSecondWavePlugin.both_ODY_AND_ILI_MULT;
import static data.scripts.RCSecondWavePlugin.ody_BASE_DIST;
import static data.scripts.RCSecondWavePlugin.ody_BASE_DIST_MULT;
import static data.scripts.RCSecondWavePlugin.ody_FUEL_MULT;
import static data.scripts.RCSecondWavePlugin.ody_INCR;
import static data.scripts.RCSecondWavePlugin.ody_LEVELS;
import static data.scripts.RCSecondWavePlugin.ody_MAX_DIST;
import static data.scripts.RCSecondWavePlugin.ody_MULT_CAPITAL;
import static data.scripts.RCSecondWavePlugin.ody_MULT_CRUISER;
import static data.scripts.RCSecondWavePlugin.ody_MULT_DESTROYER;
import static data.scripts.RCSecondWavePlugin.ody_MULT_FRIGATE;
import static data.scripts.RCSecondWavePlugin.ody_SUPPLY_MULT;

/*
    TODO:    
-Make min distance separate from incremental distance
*/

public class OdysseyModeBuff implements Buff {
    private final String id;
    private float dur;    
    
    public OdysseyModeBuff(String id, float dur) {
        this.id = id;
        this.dur = dur;
    }
    
    @Override
    public void apply(FleetMemberAPI member) {    
        float distFromCore = Global.getSector().getPlayerFleet().getLocationInHyperspace().length();
        int distPercent = 0;
        //Highest level should cap at the value given in the config, but be based on the exact max distance chosen.
        int maxLevel = (int) Math.min(Math.max(1, Math.floor(ody_MAX_DIST/ody_BASE_DIST)), ody_LEVELS);
        
        /*
        I figured out this formula on a separate spreadsheet. Basically it will scale smoothly and linearly,
        but the slope will increase depending on the current "level" (multiple of base distance)
        If you want details, feel free to ask.
        */
        if (distFromCore > ody_MAX_DIST && ody_MAX_DIST >= ody_BASE_DIST) {
            distPercent = Math.round((ody_MAX_DIST - ody_BASE_DIST*(1/ody_INCR + maxLevel*(maxLevel+1)/2 - 1)/(1/ody_INCR + maxLevel-1))
                                    * ody_BASE_DIST_MULT*(1+ody_INCR*(maxLevel-1)));
        } else {
            for (int i=ody_LEVELS; i>0; i--) {
                if (distFromCore > ody_BASE_DIST*i) {
                    distPercent = Math.round((distFromCore - ody_BASE_DIST*(1/ody_INCR + i*(i+1)/2 - 1)/(1/ody_INCR + i-1)) * ody_BASE_DIST_MULT*(1+ody_INCR*(i-1)));
                    break;
                }
            }
        }

        //If Odyssey Mode is enabled, reduce penalties (buffer day increase is done elsewhere)
        if (ILIAD_MODE) {
            distPercent *= both_ODY_AND_ILI_MULT;
        }        
        
        if (member.isFrigate()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, distPercent * ody_SUPPLY_MULT * ody_MULT_FRIGATE, "Odyssey Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, distPercent * ody_FUEL_MULT * ody_MULT_FRIGATE, "Odyssey Mode");
        }
        else if (member.isDestroyer()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, distPercent * ody_SUPPLY_MULT * ody_MULT_DESTROYER, "Odyssey Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, distPercent * ody_FUEL_MULT * ody_MULT_DESTROYER, "Odyssey Mode");
        }
        else if (member.isCruiser()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, distPercent * ody_SUPPLY_MULT * ody_MULT_CRUISER, "Odyssey Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, distPercent * ody_FUEL_MULT * ody_MULT_CRUISER, "Odyssey Mode");
        }
        else if (member.isCapital()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, distPercent * ody_SUPPLY_MULT * ody_MULT_CAPITAL, "Odyssey Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, distPercent * ody_FUEL_MULT * ody_MULT_CAPITAL, "Odyssey Mode");
        }
    }

    @Override
    public String getId() {
        return id;
    }
    @Override
    public boolean isExpired() {
        return dur <= 0;
    }

    public float getDur() {
        return dur;
    }
    
    public void setDur(float dur) {
        this.dur = dur;
    }
    
    @Override
    public void advance(float days) {
        setDur(dur);
    }
}