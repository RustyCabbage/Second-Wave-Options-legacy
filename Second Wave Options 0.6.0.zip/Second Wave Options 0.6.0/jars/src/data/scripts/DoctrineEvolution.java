package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FactionAPI.ShipPickMode;
import com.fs.starfarer.api.campaign.FactionAPI.ShipPickParams;
import com.fs.starfarer.api.campaign.FactionDoctrineAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.ShipRoles;
import com.fs.starfarer.api.util.Misc;
import static data.scripts.RCSecondWavePlugin.RCSW_VanillaFactions;
import static data.scripts.RCSecondWavePlugin.RCSWgetRemnantSystems;
import static data.scripts.RCSecondWavePlugin.de_ADD_NEW_TECHNOLOGIES;
import static data.scripts.RCSecondWavePlugin.de_AFFECT_MOD_FACTIONS;
import static data.scripts.RCSecondWavePlugin.de_ALLOW_NEGATIVE_MARKET_POINTS;
import static data.scripts.RCSecondWavePlugin.de_ALLOW_NEGATIVE_TIME_POINTS;
import static data.scripts.RCSecondWavePlugin.de_BASE_LEVEL_FOR_SCALING;
import static data.scripts.RCSecondWavePlugin.de_CAPITAL_MULT;
import static data.scripts.RCSecondWavePlugin.de_COLONY_MULT;
import static data.scripts.RCSecondWavePlugin.de_CORE_MULT;
import static data.scripts.RCSecondWavePlugin.de_EFFECT_PER_LEVEL;
import static data.scripts.RCSecondWavePlugin.de_FLAT_BONUS_POINTS;
import static data.scripts.RCSecondWavePlugin.de_GLOBAL_MULT;
import static data.scripts.RCSecondWavePlugin.de_HEAVY_INDUSTRY_MULT;
import static data.scripts.RCSecondWavePlugin.de_HIDDEN_MARKET_MULT;
import static data.scripts.RCSecondWavePlugin.de_HIGH_COMMAND_MULT;
import static data.scripts.RCSecondWavePlugin.de_MARKET_INCR_PER_CYCLE;
import static data.scripts.RCSecondWavePlugin.de_MARKET_INCR_PER_MARKET;
import static data.scripts.RCSecondWavePlugin.de_MARKET_SCORE_MULT;
import static data.scripts.RCSecondWavePlugin.de_MAX_NUM_SHIPS_FROM_DOC;
import static data.scripts.RCSecondWavePlugin.de_MAX_SHIP_QUALITY_FROM_DOC;
import static data.scripts.RCSecondWavePlugin.de_MILITARY_BASE_MULT;
import static data.scripts.RCSecondWavePlugin.de_ORBITAL_WORKS_MULT;
import static data.scripts.RCSecondWavePlugin.de_OUTPOST_MULT;
import static data.scripts.RCSecondWavePlugin.de_POINTS_PER_CYCLE;
import static data.scripts.RCSecondWavePlugin.de_RAIDER_FACTION_MULT;
import static data.scripts.RCSecondWavePlugin.de_REDUCE_AUTOFIT_PROB;
import static data.scripts.RCSecondWavePlugin.de_REMNANT_TIME_BONUS;
import static data.scripts.RCSecondWavePlugin.de_STRONGHOLD_MULT;
import static data.scripts.RCSecondWavePlugin.de_TIME_BONUS_START_YEAR;
import static data.scripts.RCSecondWavePlugin.de_USE_FLAT_BONUS;
import static data.scripts.RCSecondWavePlugin.de_USE_LEVEL_SCALING;
import static data.scripts.RCSecondWavePlugin.de_USE_MARKET_BONUS;
import static data.scripts.RCSecondWavePlugin.de_USE_TIME_BONUS;
import static data.scripts.RCSecondWavePlugin.de_USE_VANILLA_LIMIT;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import org.apache.log4j.Logger;

/*
    TODO:
-Option for affecting stability effect on doctrine
-Can I reduce late game capital spam by switching ShipSize doctrine?
-affect only showInIntelTab factions?
-consider infinite scaling with excess points

    WAS TODO, BUT NOW INDEFINITELY TABLED:
-Add console command to buff/nerf faction - probably really annoying, maybe just let bonuses be changed via console? wont stick between loads though
-Consider supporting Player faction growth? - UI problems.
-Adjust aggressiveness of local fleets if you're hostile? - Really annoying to implement
-Consider making a Hashmap <Faction, Int> so that losing markets is more painful than raiding markets. - Nah, this seems fine.
*/

public class DoctrineEvolution {

    public static Logger log = Global.getLogger(DoctrineEvolution.class);
    
    static int maxOfficerQuality = 5;
    static int maxShipQuality = 5;
    static int maxNumShips = 5;
    static int HighestNumShips = 0;
    static boolean DE_ONLY_ALERT_ONCE = true;
    static int DE_LastOverMax = 0;
    
    public void DoctrineSetup() {
        if (!de_USE_VANILLA_LIMIT) {
            if (de_ADD_NEW_TECHNOLOGIES) {
                maxOfficerQuality = 7;
            }
            maxShipQuality = (int) Math.max(5, Math.round( (de_MAX_SHIP_QUALITY_FROM_DOC/100) / Global.getSettings().getFloat("doctrineFleetQualityPerPoint") )+1);            
            maxNumShips = (int) Math.max(5, Math.round( (de_MAX_NUM_SHIPS_FROM_DOC-1) / ((Global.getSettings().getFloat("maxDoctrineNumShipsMult")-1) / 4) )+1);
        }
        HashMap<String, FactionDoctrineAPI> ogFactionDoctrine = new HashMap<String, FactionDoctrineAPI>();
        ogFactionDoctrine.clear();
        //creates a backup
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            String id = faction.getId();
            if ("player".equals(id)) {}
            else {
                FactionDoctrineAPI ogDoctrine = faction.getDoctrine().clone();
                ogFactionDoctrine.put(id, ogDoctrine);
            }
        }
        Global.getSector().getMemoryWithoutUpdate().set("$ogFactionDoctrine", ogFactionDoctrine);
    }
    
    public void DoctrineReturnToOriginal(FactionAPI faction) {
        String id = faction.getId();
        FactionDoctrineAPI doctrine = faction.getDoctrine();
        HashMap<String, FactionDoctrineAPI> ogFactionDoctrine = new HashMap<String, FactionDoctrineAPI>();
        //check if empty, else it crashes
        if (Global.getSector().getMemoryWithoutUpdate().get("$ogFactionDoctrine") != null) {
            ogFactionDoctrine = (HashMap<String, FactionDoctrineAPI>) Global.getSector().getMemoryWithoutUpdate().get("$ogFactionDoctrine");
        }
        //check if empty, else it crashes
        if (!ogFactionDoctrine.isEmpty()) {
            for (String key : ogFactionDoctrine.keySet()) {
                if (key.equals(id)) {
                    FactionDoctrineAPI ogDoctrine = (FactionDoctrineAPI) ogFactionDoctrine.get(id);
                    doctrine.setNumShips(ogDoctrine.getNumShips());
                    doctrine.setShipQuality(ogDoctrine.getShipQuality());
                    doctrine.setOfficerQuality(ogDoctrine.getOfficerQuality());
                    doctrine.setAutofitRandomizeProbability(ogDoctrine.getAutofitRandomizeProbability());
                }
            }
        } else {
            return;
        }
    }

    public float roundBetter(float value) {
        float temp = (float) Math.round(value*100);
        return temp/100;
    }    
    
    public float roundBetter(float value, int places) {
        if (places < 0) {
            places = 0;
        }        
        float mult = (float) Math.pow(10, places);
        float temp = (float) Math.round(value * mult);
        return temp / mult;
    }
    
    public float[] getMarketScores(FactionAPI faction) {
        float MarketScores[];
        MarketScores = new float [Misc.getFactionMarkets(faction).size()];
        
        int j=0;
        for (MarketAPI factionMarket : Misc.getFactionMarkets(faction)) {
            float size = factionMarket.getSize();
            float stab = factionMarket.getStabilityValue();
            if (de_ALLOW_NEGATIVE_MARKET_POINTS) {
                MarketScores[j] = size*size * (stab-5)/5;
            } else {
                MarketScores[j] = size*size * stab/10;
            }
            //hidden markets get reduced scores
            if (factionMarket.isHidden()) {
                MarketScores[j] *= de_HIDDEN_MARKET_MULT;
            }
            if (factionMarket.hasIndustry("militarybase")) {
                MarketScores[j] *= de_MILITARY_BASE_MULT;
            }
            if (factionMarket.hasIndustry("highcommand")) {
                MarketScores[j] *= de_HIGH_COMMAND_MULT;
            }
            if (factionMarket.hasIndustry("heavyindustry")) {
                MarketScores[j] *= de_HEAVY_INDUSTRY_MULT;
            }
            if (factionMarket.hasIndustry("orbitalworks")) {
                MarketScores[j] *= de_ORBITAL_WORKS_MULT;
            }
            //round to thousandths
            MarketScores[j] = roundBetter(MarketScores[j], 3);
            j++;
        }
        //sorts in ascending order
        Arrays.sort(MarketScores);
        return MarketScores;
    }
    
    public float[] getMarketScoresAdj(FactionAPI faction) {
        float MarketScores[];
        MarketScores = getMarketScores(faction);
        
        float MarketScoresAdj[];
        MarketScoresAdj = getMarketScores(faction);
        //from the highest scoring market down:
        for (int i = MarketScoresAdj.length - 1; i >= 0; i--) {
            
            //if market score is negative, use a 1x multiplier at most. Maybe refine this to adjust for options.
            if (MarketScoresAdj[i] < 0 && i >= MarketScoresAdj.length - 6) {}
            else {
                //highest scoring market
                if (i == MarketScores.length - 1) {
                    MarketScoresAdj[i] = (float) MarketScores[i] * de_CAPITAL_MULT;
                //markets 2 and 3
                } else if (i >= MarketScores.length - 3) {
                    MarketScoresAdj[i] = (float) MarketScores[i] * de_STRONGHOLD_MULT;
                //markets 4,5,6
                } else if (i >= MarketScores.length - 6) {
                    MarketScoresAdj[i] = (float) MarketScores[i] * de_CORE_MULT;
                //markets 7-10
                } else if (i >= MarketScores.length - 10) {
                    MarketScoresAdj[i] = (float) MarketScores[i] * de_COLONY_MULT;
                //further markets
                } else {
                    MarketScoresAdj[i] = (float) MarketScores[i] * de_OUTPOST_MULT;
                }
                //round to thousandths
                MarketScoresAdj[i] = roundBetter(MarketScoresAdj[i], 3);
            }
        }
        return MarketScoresAdj;
    }
        
    public float getMarketPoints(FactionAPI faction) {
        String id = faction.getId();
        float marketPoints = 0;
        int cyclesPassed = 0;
        cyclesPassed = Global.getSector().getClock().getCycle() - 206;
        FactionAPI playerFaction = Global.getSector().getFaction("player");
        
        float MarketScoreMult = de_MARKET_SCORE_MULT;
        MarketScoreMult *= (1+de_MARKET_INCR_PER_CYCLE*cyclesPassed);
        MarketScoreMult *= (1+de_MARKET_INCR_PER_MARKET * Misc.getFactionMarkets(playerFaction).size());
        
        float MarketScoresAdj[];
        MarketScoresAdj = getMarketScoresAdj(faction);
        
        for (float f : MarketScoresAdj) {
            marketPoints += f * MarketScoreMult;
        }
        //round to 10^(-5)s.
        marketPoints = roundBetter(marketPoints, 5);
        log.info("Doctrine Evolution: market points for faction '"+id+"': " + marketPoints);  
        return marketPoints;
    }
    
    public void DoctrineBonusAll(FactionAPI faction) {
        String id = faction.getId();
        FactionDoctrineAPI doctrine = faction.getDoctrine();
        float flatPoints = 0;
        float timePoints = 0;
        float marketPoints = 0;
        int cyclesPassed = 0;
        
        List<String> hiddenMarketFactions = RCSecondWavePlugin.getRaiderFactions();
        List<String> zeroMarketsFactions = RCSecondWavePlugin.getEliteFactions();
        
        if ((!de_AFFECT_MOD_FACTIONS && !RCSW_VanillaFactions.contains(id)) || "player".equals(id)) {}
        else {
            if (de_REDUCE_AUTOFIT_PROB) {
                doctrine.setAutofitRandomizeProbability(0);
            }
            if (de_USE_FLAT_BONUS) {
                flatPoints = de_FLAT_BONUS_POINTS;
                log.info("Doctrine Evolution - '"+id+"': flat points: " + flatPoints);
            }
            if (de_USE_TIME_BONUS) {
                cyclesPassed = Math.round(Global.getSector().getClock().getCycle() - de_TIME_BONUS_START_YEAR);
                if (de_ALLOW_NEGATIVE_TIME_POINTS) {
                    timePoints = (float) cyclesPassed * de_POINTS_PER_CYCLE;
                } else {
                    timePoints = (float) Math.max(0,cyclesPassed * de_POINTS_PER_CYCLE);
                }
                if (zeroMarketsFactions.contains(id)) {
                    timePoints = (float) Math.max(0,timePoints * de_REMNANT_TIME_BONUS);
                }
                log.info("Doctrine Evolution - '"+id+"': time points: " + timePoints);
            }
            if (de_USE_MARKET_BONUS && !Misc.getFactionMarkets(faction).isEmpty()) {
                marketPoints = getMarketPoints(faction);
            }
            
            //sum total points
            float totalPoints = flatPoints + timePoints + marketPoints;
            
            // Not sure that this is a good idea upon testing.
            //if hidden market faction, apply multiplier
            if (hiddenMarketFactions.contains(id)) {
                totalPoints *= de_RAIDER_FACTION_MULT;
                log.info("Doctrine Evolution - '"+id+"': Raider Faction. Total points multiplied by "+de_RAIDER_FACTION_MULT+".");
            }
            if (de_USE_LEVEL_SCALING) {
                int charLevel = Global.getSector().getPlayerStats().getLevel();
                //allow for >level 50 characters
                float levelEffect = (Math.min(charLevel,50)-de_BASE_LEVEL_FOR_SCALING)*de_EFFECT_PER_LEVEL;
                //adds a percentage (may be negative)
                totalPoints += roundBetter(totalPoints*(levelEffect/100),3);
                log.info("Doctrine Evolution - '"+id+"': Level scaling. Total points adjusted by "+roundBetter(totalPoints*(levelEffect/100),3)+".");
            }
            //Global multiplier.
            log.info("Doctrine Evolution - '"+id+"': Global multiplier. Total points multiplied by "+de_GLOBAL_MULT+".");
            totalPoints = Math.round(totalPoints*de_GLOBAL_MULT);
            log.info("Doctrine Evolution - '"+id+"': total points: " + totalPoints);
            
            boolean allocationSuccess = false;
            float excessPoints = 0;
            int scalingCost = 3;
            while (totalPoints >= 1) {
                allocationSuccess = false;
                //Officer quality only increases if ShipQuality/Quantity are equal or higher, or they're at their max values.
                if (doctrine.getOfficerQuality() < maxOfficerQuality && totalPoints >= 2
                        && (doctrine.getOfficerQuality() <= doctrine.getNumShips() || doctrine.getNumShips() == maxNumShips)
                        && (doctrine.getOfficerQuality() <= doctrine.getShipQuality() || doctrine.getShipQuality() == maxShipQuality)
                    ) {
                    totalPoints = totalPoints - 2;
                    doctrine.setOfficerQuality(doctrine.getOfficerQuality()+1);
                    allocationSuccess = true;
                }
                //ShipQuality should not increase beyond 5 if the other two have not reached 5. Doeosn't work all the time and idk why.
                if (doctrine.getShipQuality() >= 5 && (doctrine.getOfficerQuality() < 5 || doctrine.getNumShips() < 5)) {
                    log.info("Doctrine Evolution - '"+id+"': ShipQuality at 5. Raising others to 5 first.");
                }
                else if (doctrine.getShipQuality() < maxShipQuality && totalPoints >= 2) {
                    totalPoints = totalPoints - 2;
                    doctrine.setShipQuality(doctrine.getShipQuality()+1);
                    allocationSuccess = true;
                }
                if (doctrine.getNumShips() < maxNumShips && totalPoints >= 1) {
                    totalPoints--;
                    doctrine.setNumShips(doctrine.getNumShips()+1);
                    allocationSuccess = true;
                }
                if (!allocationSuccess || 
                        (doctrine.getNumShips() >= maxNumShips && doctrine.getShipQuality() >= maxShipQuality && doctrine.getOfficerQuality() >= maxOfficerQuality)) {
                    excessPoints = totalPoints;
                    log.info("Doctrine Evolution - '"+id+"': excess points: "+excessPoints);
                    totalPoints = 0;
                    log.info("Doctrine Evolution - '"+id+"': reached maximum doctrine.");
                }
            }
            while (totalPoints <= -1) {
                allocationSuccess = false;
                if (doctrine.getNumShips() > 1 && totalPoints <= -1) {
                    doctrine.setNumShips(doctrine.getNumShips()-1);
                    totalPoints++;
                    allocationSuccess = true;
                }
                if (doctrine.getShipQuality() > 1 && totalPoints <= -2) {
                    doctrine.setShipQuality(doctrine.getShipQuality()-1);
                    totalPoints = totalPoints + 2;
                    allocationSuccess = true;
                }
                if (doctrine.getOfficerQuality() > 1 && totalPoints <= -2) {
                    doctrine.setOfficerQuality(doctrine.getOfficerQuality()-1);
                    totalPoints = totalPoints + 2;
                    allocationSuccess = true;
                }                    
                if (!allocationSuccess ||
                        (doctrine.getNumShips() == 1 && doctrine.getShipQuality() == 1 && doctrine.getOfficerQuality() == 1)) {
                    totalPoints = 0;
                    log.info("Doctrine Evolution - '"+id+"': reached minimum doctrine.");
                }
            }
            while (excessPoints >= scalingCost) {
                excessPoints = excessPoints - scalingCost;
                doctrine.setNumShips(doctrine.getNumShips()+1);
                scalingCost = doctrine.getNumShips()-maxNumShips + 3;
            }
        }
    }
    
    public void ManualAddRemnantShips(CampaignFleetAPI fleet) {
        Random random = new Random();
        FactionAPI faction = fleet.getFaction();
        FactionDoctrineAPI doctrine = faction.getDoctrine();
            
        float combatPoints = 4;
        HashMap<LocationAPI, String> RCSW_RemnantSystems = RCSWgetRemnantSystems();
        if (RCSW_RemnantSystems.containsKey(fleet.getStarSystem())) {
            if (RCSW_RemnantSystems.get(fleet.getStarSystem()).equals("Low")) {
                combatPoints = 6;
            }            
            if (RCSW_RemnantSystems.get(fleet.getStarSystem()).equals("Medium")) {
                combatPoints = 8;
            }
            if (RCSW_RemnantSystems.get(fleet.getStarSystem()).equals("High")) {
                combatPoints = 12;
            }
        }

        List<String> shipRolesList = new ArrayList<String>();
        shipRolesList.clear();
        //find largest ship size used and allow up to those roles only.
        if (fleet.getNumCapitals() > 0) {
            shipRolesList.add(ShipRoles.COMBAT_SMALL); shipRolesList.add(ShipRoles.CARRIER_SMALL); shipRolesList.add(ShipRoles.PHASE_SMALL);
            shipRolesList.add(ShipRoles.COMBAT_MEDIUM); shipRolesList.add(ShipRoles.CARRIER_MEDIUM); shipRolesList.add(ShipRoles.PHASE_MEDIUM);
            shipRolesList.add(ShipRoles.COMBAT_LARGE); shipRolesList.add(ShipRoles.CARRIER_LARGE); shipRolesList.add(ShipRoles.PHASE_LARGE);
            shipRolesList.add(ShipRoles.COMBAT_CAPITAL); shipRolesList.add(ShipRoles.PHASE_CAPITAL);
        } else if (fleet.getNumCruisers() > 0) {
            shipRolesList.add(ShipRoles.COMBAT_SMALL); shipRolesList.add(ShipRoles.CARRIER_SMALL); shipRolesList.add(ShipRoles.PHASE_SMALL);
            shipRolesList.add(ShipRoles.COMBAT_MEDIUM); shipRolesList.add(ShipRoles.CARRIER_MEDIUM); shipRolesList.add(ShipRoles.PHASE_MEDIUM);
            shipRolesList.add(ShipRoles.COMBAT_LARGE); shipRolesList.add(ShipRoles.CARRIER_LARGE); shipRolesList.add(ShipRoles.PHASE_LARGE);
            combatPoints *= 0.8;
        } else if (fleet.getNumDestroyers() > 0) {
            shipRolesList.add(ShipRoles.COMBAT_SMALL); shipRolesList.add(ShipRoles.CARRIER_SMALL); shipRolesList.add(ShipRoles.PHASE_SMALL);
            shipRolesList.add(ShipRoles.COMBAT_MEDIUM); shipRolesList.add(ShipRoles.CARRIER_MEDIUM); shipRolesList.add(ShipRoles.PHASE_MEDIUM);
            combatPoints *= 0.6;
        } else {
            shipRolesList.add(ShipRoles.COMBAT_SMALL); shipRolesList.add(ShipRoles.CARRIER_SMALL); shipRolesList.add(ShipRoles.PHASE_SMALL);
            combatPoints *= 0.4;
        }
        
//        List<String> remnantShipRoles = new ArrayList<String>();
        LinkedHashMap<String, Integer> weightedRemnantShipRoles = new LinkedHashMap<String, Integer>();
        //if the remnant have a ship in that ship role, add it to the list
        for (String role : shipRolesList) {
            if (faction.getNumAvailableForRole(role, ShipPickMode.ALL) > 0) {
                //remnantShipRoles.add(role);
                weightedRemnantShipRoles.put(role, faction.getNumAvailableForRole(role, FactionAPI.ShipPickMode.ALL));
            }
        }        
        int totalWeight = 0;
        for (String role : weightedRemnantShipRoles.keySet()) {
            totalWeight += weightedRemnantShipRoles.get(role);
        }
        
        int NumShipsMult = Math.max(1,doctrine.getNumShips()-5);
        combatPoints = (int) Math.max(combatPoints, combatPoints*NumShipsMult);
        int combatPointsRange = (int) Math.round(combatPoints*1.25 - combatPoints*0.75);
        //between 75% and 125% of the original combat points value
        int combatPointsWithVariance = (int) Math.round( random.nextInt( Math.max(1,combatPointsRange) ) + combatPoints*0.75 ); 
        log.info("Fleet Bonus FP is: " + combatPointsWithVariance);
        
        int numFails = 0;
        int fpAdded = 0;
        while (combatPointsWithVariance >= 8 && numFails < totalWeight) {
            float randomPick = (float) ( Math.random()*(totalWeight-numFails) );
            String randomRole = shipRolesList.get( random.nextInt(shipRolesList.size()) );
            for (String role : weightedRemnantShipRoles.keySet()) {
                randomPick -= weightedRemnantShipRoles.get(role);
                if (randomPick <= 0.0f) {
                    randomRole = role;
//                    log.info("Adding "+randomRole+" to fleet"+fleet+".");
                    break;
                }
            }
            float value = faction.pickShipAndAddToFleet(randomRole, new ShipPickParams(ShipPickMode.ALL, combatPointsWithVariance), fleet, random);
            if (value != 0.0) {
                FleetMemberAPI newShip = (FleetMemberAPI) fleet.getFleetData().getMembersListCopy().get(fleet.getNumMembersFast()-1);
                combatPointsWithVariance -= newShip.getFleetPointCost();
                fpAdded += newShip.getFleetPointCost();
//                numFails = 0;
            } else {
                numFails++;
            }
        }
        log.info("FP added: "+fpAdded+".");

/*        
        int numFails = 0;
        while (combatPointsWithVariance >= 8 && numFails < remnantShipRoles.size()) {
            //use progressively smaller ship roles for each failure
            int randomPick = random.nextInt(remnantShipRoles.size()-numFails);
            String randomRole = remnantShipRoles.get(randomPick);
            float value = faction.pickShipAndAddToFleet(randomRole, new ShipPickParams(ShipPickMode.ALL, combatPointsWithVariance), fleet, random);
            if (!(value == 0.0)) {
                FleetMemberAPI newShip = (FleetMemberAPI) fleet.getFleetData().getMembersListCopy().get(fleet.getNumMembersFast()-1);
                combatPointsWithVariance -= newShip.getFleetPointCost();
                numFails = 0;
            } else {
                numFails++;
            }
        }
*/
    }

        
    public void AlertToChangeMaxAIShips() {        
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            FactionDoctrineAPI doctrine = faction.getDoctrine();
            if (doctrine.getNumShips() > HighestNumShips) {
                HighestNumShips = doctrine.getNumShips();
            }
        }
        //Currently checking for every +100% bonus to NumShips
        float IncrPerNumShips = (Global.getSettings().getFloat("maxDoctrineNumShipsMult")-1)/4;
        int OverMax = (int) Math.floor((HighestNumShips-5)*IncrPerNumShips);
        if ((OverMax + 30) > Global.getSettings().getInt("maxShipsInAIFleet")){// && OverMax > DE_LastOverMax) {
            Global.getSector().getCampaignUI().addMessage(
                "Fleet doctrine has been updated. It is recommended that you increase `maxShipsInAIFleet` in settings.json to a value of: "+(30+OverMax)+".", Color.MAGENTA);
            DE_LastOverMax = OverMax;
        }
        if ((OverMax + 30) < Global.getSettings().getInt("maxShipsInAIFleet") && DE_ONLY_ALERT_ONCE) {
            Global.getSector().getCampaignUI().addMessage(
                "Note: the current settings for `maxShipsInAIFleet` are not recommended. The current recommended value is: "+(30+OverMax)+".", Color.MAGENTA);
            DE_ONLY_ALERT_ONCE = false;
        }       
    }    
    
    public void addNewTechnologies(FactionAPI faction) {
        String id = faction.getId();
        //remnant specific adjustments
        if ("remnant".equals(id)) {
            faction.addPriorityWeapon("phasecl");
            if (faction.knowsWeapon("pilum")) {
                faction.removeKnownWeapon("pilum");
            }
        }
        if (!RCSW_VanillaFactions.contains(id) || "player".equals(id) || "remnant".equals(id) || "derelict".equals(id)) {
            log.info("Mod/player/redacted faction - will not add new tech.");
            return;
        }
        
        //allow shuffling of commander skills
        faction.getDoctrine().setCommanderSkillsShuffleProbability( (float) Math.max(0, (float)(faction.getDoctrine().getOfficerQuality()-4) * 0.1f));
        
        //strength points = sum of officer quality, ship quality, num ships.
        int strengthPoints = faction.getDoctrine().getTotalStrengthPoints();
        //int shipQuality = faction.getDoctrine().getShipQuality();
        
        //affects everything except pirates and LP at game start.
        if (strengthPoints >= 8) {
            //unlock essential and somewhat useful hullmods
            if (!faction.knowsHullMod("targetingunit")) {
                faction.addKnownHullMod("targetingunit");        
                faction.addPriorityHullMod("targetingunit");
                //remove DTC? not necessary
            } else {
                faction.addPriorityHullMod("targetingunit");
            }
            if (!faction.knowsHullMod("expanded_deck_crew")) {
                faction.addKnownHullMod("expanded_deck_crew");
                faction.addPriorityHullMod("expanded_deck_crew");
            } else {
                faction.addPriorityHullMod("expanded_deck_crew");
            }
            if (!faction.knowsHullMod("autorepair")) {
                faction.addKnownHullMod("autorepair");
            }
            if (!faction.knowsHullMod("extendedshieldemitter")) {
                faction.addKnownHullMod("extendedshieldemitter");
            }
            if (!faction.knowsHullMod("hiressensors")) {
                faction.addKnownHullMod("hiressensors");
            }
            //removes terrible single fire missiles and terrible weapons
            if (faction.knowsWeapon("hammer_single")) {
                faction.removeKnownWeapon("hammer_single");
            }
            if (faction.knowsWeapon("harpoon_single")) {
                faction.removeKnownWeapon("harpoon_single");
            }
            if (faction.knowsWeapon("mining_laser")) {
                faction.removeKnownWeapon("mining_laser");
            }
            if (faction.knowsWeapon("guardian")) {
                faction.removeKnownWeapon("guardian");
            }
            //adds officer skills
            if (!faction.getDoctrine().getCommanderSkills().contains("officer_management") && faction.getDoctrine().getOfficerQuality()>=3) {
                faction.getDoctrine().getCommanderSkills().add("officer_management");
            }
        }
        //affects hegemony and persean league at game start.
        if (strengthPoints >= 10) {
            //unlock more high tech hullmods:
            if (!faction.knowsHullMod("hardenedshieldemitter")) {
                faction.addKnownHullMod("hardenedshieldemitter");
            }
            if (!faction.knowsHullMod("eccm")) {
                faction.addKnownHullMod("eccm");
            }
            if (!faction.knowsHullMod("ecm")) {
                faction.addKnownHullMod("ecm");
            }
            if (!faction.knowsHullMod("pointdefenseai")) {
                faction.addKnownHullMod("pointdefenseai");
            }
            //unlock decent weapons
            if (!faction.knowsWeapon("railgun")) {
                faction.addKnownWeapon("railgun", false);
            }
            if (!faction.knowsWeapon("dualflak")) {
                faction.addKnownWeapon("dualflak", false);
            }
            if (!faction.knowsWeapon("hveldriver")) {
                faction.addKnownWeapon("hveldriver", false);
            }
            if (!faction.knowsWeapon("pdburst")) {
                faction.addKnownWeapon("pdburst", false);
            }
            if (!faction.knowsWeapon("atropos")) {
                faction.addKnownWeapon("atropos", false);
            }
            if (!faction.knowsWeapon("phasecl")) {
                faction.addKnownWeapon("phasecl", false);
//                faction.addPriorityWeapon("phasecl");
//            } else {
//                faction.addPriorityWeapon("phasecl");
            }
            //pls gryphons stop using salamanders
            if (faction.knowsWeapon("locust")) {
                faction.addPriorityWeapon("locust");
            }
            //removes pilum. One ship uses it atm I think, so should be safe to remove
            if (faction.knowsWeapon("pilum")) {
                faction.removeKnownWeapon("pilum");
            }
            //remove more bad weapons and the worst fighter in the game
            if (faction.knowsWeapon("atropos_single")) {
                faction.removeKnownWeapon("atropos_single");
            }
            if (faction.knowsWeapon("sabot_single")) {
                faction.removeKnownWeapon("sabot_single");
            }
            if (faction.knowsWeapon("shredder")) {
                faction.removeKnownWeapon("shredder");
            }
            if (faction.knowsWeapon("heavyburst")) {
                faction.removeKnownWeapon("heavyburst");
            }
            if (faction.knowsFighter("warthog_Fighter")) {
                faction.removeKnownFighter("warthog_Fighter");
            }
            //adds commander skills
            if (!faction.getDoctrine().getCommanderSkills().contains("coordinated_maneuvers")) {
                faction.getDoctrine().getCommanderSkills().add("coordinated_maneuvers");
            }
        }
        if (strengthPoints >= 12) {
            //unlock more good weapons and the best fighter in the game:
            if (!faction.knowsWeapon("heavyneedler")) {
                faction.addKnownWeapon("heavyneedler", false);
            }
            if (!faction.knowsWeapon("amblaster")) {
                faction.addKnownWeapon("amblaster", false);
            }
            if (!faction.knowsWeapon("sabotpod")) {
                faction.addKnownWeapon("sabotpod", false);
            }
            if (!faction.knowsFighter("thunder_wing")) {
                faction.addKnownFighter("thunder_wing", false);
            }
            //adds commander skills
            if (!faction.getDoctrine().getCommanderSkills().contains("fighter_doctrine") && faction.getDoctrine().getCarriers()>=3) {
                faction.getDoctrine().getCommanderSkills().add("fighter_doctrine");
            }         
        }
        if (strengthPoints >= 14) {
            //unlock large weapons and somewhat lore-unfriendly longbows
            if (!faction.knowsWeapon("gauss")) {
                faction.addKnownWeapon("gauss", false);
            }  
            if (!faction.knowsWeapon("tachyonlance")) {
                faction.addKnownWeapon("tachyonlance", false);
            }
            if (!faction.knowsFighter("longbow_wing")) {
                faction.addKnownFighter("longbow_wing", false);
            }
            //add commander skills, remove worse ones
            if (!faction.getDoctrine().getCommanderSkills().contains("ship_design") && faction.getDoctrine().getShipQuality()>=5) {
                if (faction.getDoctrine().getCommanderSkills().contains("fighter_doctrine") && faction.getDoctrine().getCarriers()<5) {
                    faction.getDoctrine().getCommanderSkills().remove("fighter_doctrine");
                }
                faction.getDoctrine().getCommanderSkills().add("ship_design");
            }   
        }
        //adds the almighty Electronic Warfare
        if (strengthPoints >= 16) {
            if (!faction.knowsFighter("wasp_wing")) {
                faction.addKnownFighter("wasp_wing", false);
            }
            //adds commander skills, remove worse ones
            if (!faction.getDoctrine().getCommanderSkills().contains("electronic_warfare")) {
                if (faction.getDoctrine().getCommanderSkills().contains("coordinated_maneuvers")) {
                    faction.getDoctrine().getCommanderSkills().remove("coordinated_maneuvers");
                }
                faction.getDoctrine().getCommanderSkills().add("electronic_warfare");
            }               
        }        
        // somewhat non-lore-friendly, so requires a relatively high number of points.
        if (strengthPoints >= 18) {
            //unlock more LPCs:
            /*
            if (!faction.knowsFighter("piranha_wing")) {
                faction.addKnownFighter("piranha_wing", false);
            }
            if (!faction.knowsFighter("perdition_wing")) {
                faction.addKnownFighter("perdition_wing", false);
            }
            */
            if (!faction.knowsFighter("xyphos_wing")) {
                faction.addKnownFighter("xyphos_wing", false);
            }
            if (!faction.knowsFighter("dagger_wing")) {
                faction.addKnownFighter("dagger_wing", false);
            }  
        }        
    }

}