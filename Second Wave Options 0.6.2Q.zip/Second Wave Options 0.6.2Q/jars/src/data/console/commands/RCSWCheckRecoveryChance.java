package data.console.commands;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import org.lazywizard.console.Console;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;

public class RCSWCheckRecoveryChance implements BaseCommand {
    
    @Override
    public BaseCommand.CommandResult runCommand(String args, BaseCommand.CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
        
        for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersInPriorityOrder()) {
            float chance = Global.getSettings().getFloat("baseOwnShipRecoveryChance");
            Console.showMessage("For ship "+member.getHullId()+" - "+member.getShipName()+":");
            Console.showMessage("Base recovery chance: "+chance+".");
            chance = member.getStats().getDynamic().getValue(Stats.INDIVIDUAL_SHIP_RECOVERY_MOD, chance);
            if (chance < 0) chance = 0;
            if (chance > 1f) chance = 1f;
            Console.showMessage("Updated recovery chance: "+chance+".");
            Console.showMessage("----------------------------------");
        }
        return CommandResult.SUCCESS;
    }
}