package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.RCSecondWavePlugin.ODYSSEY_MODE;
import static data.scripts.RCSecondWavePlugin.both_ODY_AND_ILI_MULT;
import static data.scripts.RCSecondWavePlugin.iliAlertOnce;
import static data.scripts.RCSecondWavePlugin.iliTimeUnsafe;
import static data.scripts.RCSecondWavePlugin.ili_FUEL_MULT;
import static data.scripts.RCSecondWavePlugin.ili_MULT_CAPITAL;
import static data.scripts.RCSecondWavePlugin.ili_MULT_CRUISER;
import static data.scripts.RCSecondWavePlugin.ili_MULT_DESTROYER;
import static data.scripts.RCSecondWavePlugin.ili_MULT_FRIGATE;
import static data.scripts.RCSecondWavePlugin.ili_PERC_PER_DAY;
import static data.scripts.RCSecondWavePlugin.ili_BUFFER_DAYS;
import static data.scripts.RCSecondWavePlugin.ili_DO_NOT_ALERT;
import static data.scripts.RCSecondWavePlugin.ili_MAX_DAYS;
import static data.scripts.RCSecondWavePlugin.ili_SUPPLY_MULT;
import java.awt.Color;

/*
    TODO:
-Consider non-linear progression.
-Consider slowly dropping it down instead of instantly.
*/

public class IliadModeBuff implements Buff {
    private final String id;
    private float dur;    
    
    public IliadModeBuff(String id, float dur) {
        this.id = id;
        this.dur = dur;
    }
    
    @Override
    public void apply(FleetMemberAPI member) {    
        float iliTimeUnsafeBuff = iliTimeUnsafe;
        int timePercent = 0;
        
        //If above max unsafe days, cap the penalties
        if (iliTimeUnsafeBuff > (ili_BUFFER_DAYS + ili_MAX_DAYS)) {
            timePercent = (int) Math.round(ili_MAX_DAYS * ili_PERC_PER_DAY);
        }
        //Otherwise, penalties begin if buffer days are expired.
        else if (iliTimeUnsafeBuff > ili_BUFFER_DAYS) {
                timePercent = (int) Math.round((iliTimeUnsafe - ili_BUFFER_DAYS) * ili_PERC_PER_DAY);
                if (!ili_DO_NOT_ALERT) {
                    if (iliAlertOnce) {
                        Global.getSector().getCampaignUI().addMessage("Iliad Mode buffer expired: find a friendly market to dock in or your supply and fuel consumption will increase.",Color.YELLOW);
                        iliAlertOnce = false;
                    }
                }
        }
        
        //If Odyssey Mode is enabled, reduce penalties (buffer day increase is done elsewhere)
        if (ODYSSEY_MODE) {
            timePercent *= both_ODY_AND_ILI_MULT;
        }
        
        if (member.isFrigate()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, timePercent * ili_SUPPLY_MULT * ili_MULT_FRIGATE, "Iliad Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, timePercent * ili_FUEL_MULT * ili_MULT_FRIGATE, "Iliad Mode");
        }
        else if (member.isDestroyer()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, timePercent * ili_SUPPLY_MULT * ili_MULT_DESTROYER, "Iliad Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, timePercent * ili_FUEL_MULT * ili_MULT_DESTROYER, "Iliad Mode");
        }
        else if (member.isCruiser()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, timePercent * ili_SUPPLY_MULT * ili_MULT_CRUISER, "Iliad Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, timePercent * ili_FUEL_MULT * ili_MULT_CRUISER, "Iliad Mode");
        }
        else if (member.isCapital()) {
            member.getStats().getSuppliesPerMonth().modifyPercent(id, timePercent * ili_SUPPLY_MULT * ili_MULT_CAPITAL, "Iliad Mode");
            member.getStats().getFuelUseMod().modifyPercent(id, timePercent * ili_FUEL_MULT * ili_MULT_CAPITAL, "Iliad Mode");
        }
    }

    @Override
    public String getId() {
        return id;
    }
    @Override
    public boolean isExpired() {
        return dur <= 0;
    }

    public float getDur() {
        return dur;
    }
    
    public void setDur(float dur) {
        this.dur = dur;
    }
    
    @Override
    public void advance(float days) {
        setDur(dur);
    }    
}
