package data.scripts;

import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.RCSecondWavePlugin.cr_MULT_CAPITAL;
import static data.scripts.RCSecondWavePlugin.cr_MULT_CRUISER;
import static data.scripts.RCSecondWavePlugin.cr_MULT_DESTROYER;
import static data.scripts.RCSecondWavePlugin.cr_MULT_FRIGATE;

/* TODO:
Should this affect stations?
*/

public class SlowCRBuff implements Buff {
    private final String id;
    private float dur;
    
    public SlowCRBuff(String id, float dur) {
        this.id = id;
        this.dur = dur;
    }
    
    @Override
    public void apply(FleetMemberAPI member) {
        if (!member.getStats().getBaseCRRecoveryRatePercentPerDay().getMultMods().containsKey(id)) {
            if (member.isFrigate()) {
                member.getStats().getBaseCRRecoveryRatePercentPerDay().modifyMult(id, cr_MULT_FRIGATE, "Strained Logistics");
            }
            else if (member.isDestroyer()) {
                member.getStats().getBaseCRRecoveryRatePercentPerDay().modifyMult(id, cr_MULT_DESTROYER, "Strained Logistics");
            }
            else if (member.isCruiser()) {
                member.getStats().getBaseCRRecoveryRatePercentPerDay().modifyMult(id, cr_MULT_CRUISER, "Strained Logistics");
            }
            else if (member.isCapital()) {
                member.getStats().getBaseCRRecoveryRatePercentPerDay().modifyMult(id, cr_MULT_CAPITAL, "Strained Logistics");
            }
        }
    }

    @Override
    public String getId() {
        return id;
    }
    @Override
    public boolean isExpired() {
        return dur <= 0;
    }

    public float getDur() {
        return dur;
    }
    
    public void setDur(float dur) {
        this.dur = dur;
    }
    
    @Override
    public void advance(float days) {
        setDur(dur);
    }
}