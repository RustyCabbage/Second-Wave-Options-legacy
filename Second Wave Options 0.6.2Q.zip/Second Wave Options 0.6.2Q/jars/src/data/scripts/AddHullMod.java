package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.AddHullMod.log;
import static data.scripts.RCSecondWavePlugin.hm_AFFECTS_PLAYER;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;


        
public class AddHullMod {
    public List<CampaignFleetAPI> HullModAffectedFleets = new ArrayList<CampaignFleetAPI>();
    String hullModID = "rcsw_salvage_experience";
    public static Logger log = Global.getLogger(ApplyRCSWChanges.class);
    
    public void addHullModToShips() {
        LocationAPI currentLoc = Global.getSector().getCurrentLocation();        
        for (CampaignFleetAPI localFleet : currentLoc.getFleets()) {
            //should not affect previously affected non-player fleets
            if (HullModAffectedFleets.contains(localFleet) && !localFleet.isPlayerFleet()) {
                //log.info(localFleet.getNameWithFaction()+" already has the hull mod.");
            }
            else {
                //log.info("Adding Second Wave Hullmod to "+localFleet.getNameWithFaction());
                for (FleetMemberAPI member : localFleet.getFleetData().getMembersListCopy()) {
                    ShipVariantAPI variant = member.getVariant();
                    if (!variant.hasHullMod(hullModID)) {
                        variant.addPermaMod(hullModID);
                        //log.info("Added Second Wave Hullmod to "+variant.getFullDesignationWithHullName());
                    }
                    member.updateStats();
                }
                localFleet.forceSync();
                //make sure to only add player fleet to the list once.
                if (!HullModAffectedFleets.contains(localFleet)) {
                    HullModAffectedFleets.add(localFleet);
                    log.info("Added Second Wave Hullmod to "+localFleet.getNameWithFaction());
                }
            }
        }
    }
    
    public void removeHullModFromPlayerFleet() {
        // removes hullmod from player's fleet if set as such in settings
        for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
            ShipVariantAPI variant = member.getVariant();
            if (variant.hasHullMod(hullModID)) {
                variant.removePermaMod(hullModID);
                log.info("Removed Second Wave Hullmod from player fleet.");
            }
            member.updateStats();
        }
    }
    
    public void hullModCleanup() {
        for (CampaignFleetAPI fleet : HullModAffectedFleets) {
            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                ShipVariantAPI variant = member.getVariant();
                if (variant.hasHullMod(hullModID)) {
                    variant.removePermaMod(hullModID);
                }
                member.updateStats();
            }
            fleet.forceSync();
        }
        HullModAffectedFleets.clear();
        log.info("Cleaned up hull mods.");
    }
}