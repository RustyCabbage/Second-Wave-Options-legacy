package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.util.Misc;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

/*
    TODO:
~~sooner?~~


~~1.0?~~
-get rid of static vars.
-move buff manager stuff to hullmod. OR MAYBE DON'T because you can't make it affect allies and enemies separately.
-See https://fractalsoftworks.com/forum/index.php?topic=15262.msg246880#msg246880

//IDEA//
-Hullmod (d-mod) that combines effects of IliadMode/SlowCR/AdjustedSensors
-Over time or after combat, ships accrue points that lead to negative effects
-They can be repaired for free in storage (losing points over time), or for d-mod restore prices.
////////

~~PROBABLY NEVER~~
-Special menu to turn on/off options?
-Comment code because apparently other people actually look at this (sorry)
-Check only inflated fleets, now that I actually know what that is.

    IDEAS:
-Not Created Equal - too much like SL?
-Red Fog - CR probably does this well enough...
*/

public class RCSecondWavePlugin extends BaseModPlugin {

    public static boolean RCSW_UNINSTALL = false;
    public static boolean RCSW_RELOAD = true;
    
    private static final String SW_SETTINGS = "RCSW_SETTINGS.ini";
//
    public static boolean SLOW_CR;
    public static float cr_MULT_FRIGATE;
    public static float cr_MULT_DESTROYER;
    public static float cr_MULT_CRUISER;
    public static float cr_MULT_CAPITAL;
//
    public static boolean ODYSSEY_MODE;
    public static float ody_BASE_DIST;
    public static float ody_MAX_DIST;
    public static float ody_BASE_DIST_MULT;
    public static float ody_INCR;
    public static int ody_LEVELS;
    public static float ody_SUPPLY_MULT;
    public static float ody_FUEL_MULT;
    public static float ody_MULT_FRIGATE;
    public static float ody_MULT_DESTROYER;
    public static float ody_MULT_CRUISER;
    public static float ody_MULT_CAPITAL;
//
    public static boolean DARK_SECTOR;
    public static boolean dark_SHIP_PLAYER_ONLY;
    public static float dark_SHIP_SENSOR_STR_FLAT;
    public static float dark_SHIP_SENSOR_PRO_FLAT;
    public static float dark_SENSOR_SIZE_CHANGE_RANGE;
    public static float dark_FLEET_SENSOR_STR_MULT;
    public static float dark_FLEET_SENSOR_PRO_MULT;
    public static float dark_NEG_REP_SENSOR_INCR_MAX;
//
    public static boolean SECURE_MARKETS_NEW_GAME;
    public static boolean sm_AFFECT_MOD_FACTIONS;
    public static boolean sm_ADD_GROUND_DEFENSES;
        public static int sm_SIZE_FOR_HEAVY_BATTERIES;
    public static int sm_ADD_MILITARY_BASE;
        public static int sm_SIZE_FOR_HIGH_COMMAND;
        public static int sm_SIZE_FOR_MILITARY_BASE;
    public static int sm_ADD_PATROL_HQ;
    public static int sm_ADD_STATIONS;
        public static int sm_SIZE_FOR_STAR_FORTRESS;
        public static int sm_SIZE_FOR_BATTLE_STATION;
        public static int sm_SIZE_FOR_ORBITAL_STATION;
    public static int sm_ADD_PLANETARY_SHIELD;
        public static boolean sm_SHIELD_REQUIRE_PLAYER_KNOWN;
        public static int sm_ADD_SHIELD_START_YEAR;
        public static float sm_SCORE_FOR_SHIELD;
//
    public static boolean DOCTRINE_EVOLUTION;
    public static float de_GLOBAL_MULT;
    public static boolean de_USE_VANILLA_LIMIT;
        public static float de_MAX_SHIP_QUALITY_FROM_DOC;
        public static float de_MAX_NUM_SHIPS_FROM_DOC;
    public static boolean de_AFFECT_MOD_FACTIONS;
    public static boolean de_REDUCE_AUTOFIT_PROB;
    public static boolean de_ADD_NEW_TECHNOLOGIES;
    public static boolean de_USE_FLAT_BONUS;
        public static float de_FLAT_BONUS_POINTS;
    public static boolean de_USE_TIME_BONUS;
        public static int de_TIME_BONUS_START_YEAR;
        public static boolean de_ALLOW_NEGATIVE_TIME_POINTS;
        public static float de_POINTS_PER_CYCLE;
        public static float de_REMNANT_TIME_BONUS;
    public static boolean de_USE_MARKET_BONUS;
        public static boolean de_ALLOW_NEGATIVE_MARKET_POINTS;
        public static float de_MARKET_SCORE_MULT;
        public static float de_MARKET_INCR_PER_CYCLE;
        public static float de_MARKET_INCR_PER_MARKET;
        
        public static float de_HIDDEN_MARKET_MULT;
        public static float de_MILITARY_BASE_MULT;
        public static float de_HIGH_COMMAND_MULT;
        public static float de_HEAVY_INDUSTRY_MULT;
        public static float de_ORBITAL_WORKS_MULT;
        
        public static float de_CAPITAL_MULT;
        public static float de_STRONGHOLD_MULT;
        public static float de_CORE_MULT;
        public static float de_COLONY_MULT;
        public static float de_OUTPOST_MULT;
        
    public static float de_RAIDER_FACTION_MULT;
    public static boolean de_USE_LEVEL_SCALING;
        public static int de_BASE_LEVEL_FOR_SCALING;
        public static float de_EFFECT_PER_LEVEL;
    public static boolean de_ALLOW_AI_FLEET_SIZE_ALERTS;
//
    public static boolean ILIAD_MODE;
    public static float ili_MIN_REP;
    public static float ili_BUFFER_DAYS;
    public static float ili_MAX_DAYS;
    public static float ili_PERC_PER_DAY;
    public static float ili_SUPPLY_MULT;
    public static float ili_FUEL_MULT;
    public static float ili_MULT_FRIGATE;
    public static float ili_MULT_DESTROYER;
    public static float ili_MULT_CRUISER;
    public static float ili_MULT_CAPITAL;
    public static boolean ili_DO_NOT_ALERT;
    public static float iliTimeUnsafe;
    public static boolean iliAlertOnce = true;
//
    public static boolean HULL_MOD;
    public static boolean hm_AFFECTS_PLAYER;
    // not working atm
    public static Double hm_BASE_MULT_FRIGATE;
    public static Double hm_BASE_MULT_DESTROYER;
    public static Double hm_BASE_MULT_CRUISER;
    public static Double hm_BASE_MULT_CAPITAL;
    public static Double hm_INCR_PER_LEVEL_FRIGATE;
    public static Double hm_INCR_PER_LEVEL_DESTROYER;
    public static Double hm_INCR_PER_LEVEL_CRUISER;
    public static Double hm_INCR_PER_LEVEL_CAPITAL;
    //
//
    public static float both_ODY_AND_ILI_MULT;
    
    public static void loadRCSWSettings() throws IOException, JSONException {
        JSONObject settings = Global.getSettings().loadJSON(SW_SETTINGS);
        SLOW_CR = settings.getBoolean("slowCR");
        ODYSSEY_MODE = settings.getBoolean("odysseyMode");
        DARK_SECTOR = settings.getBoolean("darkSector");        
        SECURE_MARKETS_NEW_GAME = settings.getBoolean("secureMarketsNewGame");
        DOCTRINE_EVOLUTION = settings.getBoolean("doctrineEvolution");
        ILIAD_MODE = settings.getBoolean("iliadMode");
        HULL_MOD = settings.getBoolean("useHullMod");
        
//        SLOW_CR
            cr_MULT_FRIGATE = (float) settings.getDouble("slowCRPerDayMultFrigate");
            cr_MULT_DESTROYER = (float) settings.getDouble("slowCRPerDayMultDestroyer");
            cr_MULT_CRUISER = (float) settings.getDouble("slowCRPerDayMultCruiser");
            cr_MULT_CAPITAL = (float) settings.getDouble("slowCRPerDayMultCapital");
//        ODYSSEY_MODE
            ody_BASE_DIST = (float) settings.getDouble("odysseyBaseDist");
            ody_MAX_DIST = (float) settings.getDouble("odysseyMaxDist");
            ody_BASE_DIST_MULT = (float) settings.getDouble("odysseyBaseDistMult");
            ody_INCR = (float) settings.getDouble("odysseyIncr");
            ody_LEVELS = settings.getInt("odysseyLevels");
            ody_SUPPLY_MULT = (float) settings.getDouble("odysseySupplyMult");
            ody_FUEL_MULT = (float) settings.getDouble("odysseyFuelMult");
            ody_MULT_FRIGATE = (float) settings.getDouble("odysseyMultFrigate");
            ody_MULT_DESTROYER = (float) settings.getDouble("odysseyMultDestroyer");
            ody_MULT_CRUISER = (float) settings.getDouble("odysseyMultCruiser");
            ody_MULT_CAPITAL = (float) settings.getDouble("odysseyMultCapital");
//        DARK_SECTOR
            dark_SHIP_PLAYER_ONLY = settings.getBoolean("DSshipOnlyAffectsPlayer");
            dark_SHIP_SENSOR_STR_FLAT = (float) settings.getDouble("DSshipSensorStrFlat");
            dark_SHIP_SENSOR_PRO_FLAT = (float) settings.getDouble("DSshipSensorProFlat");
            dark_SENSOR_SIZE_CHANGE_RANGE = (float) settings.getDouble("DSsensorSizeChangeRange");
            dark_FLEET_SENSOR_STR_MULT = (float) settings.getDouble("DSfleetSensorStrMult");
            dark_FLEET_SENSOR_PRO_MULT = (float) settings.getDouble("DSfleetSensorProMult");
            dark_NEG_REP_SENSOR_INCR_MAX = (float) settings.getDouble("DSnegRepSensorIncrMax");
//        SECURE_MARKETS
            sm_AFFECT_MOD_FACTIONS = settings.getBoolean("SMaffectModFactions");
            sm_ADD_GROUND_DEFENSES = settings.getBoolean("SMaddGroundDefenses");
                sm_SIZE_FOR_HEAVY_BATTERIES = settings.getInt("SMsizeForHeavyBatteries");
            sm_ADD_MILITARY_BASE = settings.getInt("SMaddMilitaryBase");
                sm_SIZE_FOR_HIGH_COMMAND = settings.getInt("SMsizeForHighCommand");
                sm_SIZE_FOR_MILITARY_BASE = settings.getInt("SMsizeForMilitaryBase");
            sm_ADD_PATROL_HQ = settings.getInt("SMaddPatrolHQ");
            sm_ADD_STATIONS = settings.getInt("SMaddStations");
                sm_SIZE_FOR_STAR_FORTRESS = settings.getInt("SMsizeForStarFortress");
                sm_SIZE_FOR_BATTLE_STATION = settings.getInt("SMsizeForBattleStation");
                sm_SIZE_FOR_ORBITAL_STATION = settings.getInt("SMsizeForOrbitalStation");
            sm_ADD_PLANETARY_SHIELD = settings.getInt("SMaddPlanetaryShields");
                sm_SHIELD_REQUIRE_PLAYER_KNOWN = settings.getBoolean("SMshieldRequirePlayerKnown");
                sm_ADD_SHIELD_START_YEAR = settings.getInt("SMaddShieldStartYear");
                sm_SCORE_FOR_SHIELD = (float) settings.getDouble("SMscoreForShield");
//        DOCTRINE_EVOLUTION
            de_GLOBAL_MULT = (float) settings.getDouble("DEglobalMult");
            de_USE_VANILLA_LIMIT = settings.getBoolean("DEuseVanillaLimit");
                de_MAX_SHIP_QUALITY_FROM_DOC = (float) settings.getDouble("DEmaxShipQualityFromDoc");
                de_MAX_NUM_SHIPS_FROM_DOC = (float) settings.getDouble("DEmaxNumShipsFromDoc");
            de_AFFECT_MOD_FACTIONS = settings.getBoolean("DEaffectModFactions");
            de_REDUCE_AUTOFIT_PROB = settings.getBoolean("DEreduceAutofitProb");
            de_ADD_NEW_TECHNOLOGIES = settings.getBoolean("DEaddNewTechnologies");
            de_USE_FLAT_BONUS =  settings.getBoolean("DEuseFlatBonus");
                de_FLAT_BONUS_POINTS = (float) settings.getDouble("DEflatBonusPoints");
            de_USE_TIME_BONUS = settings.getBoolean("DEuseTimeBonus");
                de_TIME_BONUS_START_YEAR = settings.getInt("DEtimeBonusStartYear");
                de_ALLOW_NEGATIVE_TIME_POINTS = settings.getBoolean("DEallowNegTimePoints");
                de_POINTS_PER_CYCLE = (float) settings.getDouble("DEpointsPerCycle");
                de_REMNANT_TIME_BONUS = (float) settings.getDouble("DEredactedTimeBonus");
            de_USE_MARKET_BONUS = settings.getBoolean("DEuseMarketBonus");
                de_ALLOW_NEGATIVE_MARKET_POINTS = settings.getBoolean("DEallowNegMarketPoints");
                de_MARKET_SCORE_MULT = (float) settings.getDouble("DEmarketScoreMult");
                de_MARKET_INCR_PER_CYCLE = (float) settings.getDouble("DEmarketIncrPerCycle");
                de_MARKET_INCR_PER_MARKET = (float) settings.getDouble("DEmarketIncrPerColony");
                de_HIDDEN_MARKET_MULT = (float) settings.getDouble("DEhiddenMarketMult");

                de_MILITARY_BASE_MULT = (float) settings.getDouble("DEmilitaryBaseMult"); 
                de_HIGH_COMMAND_MULT = (float) settings.getDouble("DEhighCommandMult");
                de_HEAVY_INDUSTRY_MULT = (float) settings.getDouble("DEheavyIndustryMult");
                de_ORBITAL_WORKS_MULT = (float) settings.getDouble("DEorbitalWorksMult");               

                de_CAPITAL_MULT = (float) settings.getDouble("DEcapitalMult");
                de_STRONGHOLD_MULT = (float) settings.getDouble("DEstrongholdMult");
                de_CORE_MULT = (float) settings.getDouble("DEcoreMult");
                de_COLONY_MULT = (float) settings.getDouble("DEcolonyMult");
                de_OUTPOST_MULT = (float) settings.getDouble("DEoutpostMult");
                
            de_RAIDER_FACTION_MULT = (float) settings.getDouble("DEraiderFactionMult");
            de_USE_LEVEL_SCALING = settings.getBoolean("DEuseLevelScaling");
                de_BASE_LEVEL_FOR_SCALING = settings.getInt("DEbaseLevelForScaling");
                de_EFFECT_PER_LEVEL = (float) settings.getDouble("DEeffectPerLevel");
            de_ALLOW_AI_FLEET_SIZE_ALERTS = settings.getBoolean("DEallowAIFleetSizeAlert");
//        ILIAD_MODE
            ili_MIN_REP = (float) settings.getDouble("iliadMinRep");
            ili_BUFFER_DAYS = (float) settings.getDouble("iliadBufferDays");
            ili_MAX_DAYS = (float) settings.getDouble("iliadMaxDays");
            ili_PERC_PER_DAY = (float) settings.getDouble("iliadPercentPerDay");
            ili_SUPPLY_MULT = (float) settings.getDouble("iliadSupplyMult");
            ili_FUEL_MULT = (float) settings.getDouble("iliadFuelMult");
            ili_MULT_FRIGATE = (float) settings.getDouble("iliadMultFrigate");
            ili_MULT_DESTROYER = (float) settings.getDouble("iliadMultDestroyer");
            ili_MULT_CRUISER = (float) settings.getDouble("iliadMultCruiser");
            ili_MULT_CAPITAL = (float) settings.getDouble("iliadMultCapital");
            ili_DO_NOT_ALERT = settings.getBoolean("iliadDoNotAlert");
//        HULL MOD
            hm_AFFECTS_PLAYER = settings.getBoolean("HMaffectsPlayer");
            // not working atm
            hm_BASE_MULT_FRIGATE = settings.getDouble("HMbaseMultFrigate");
            hm_BASE_MULT_DESTROYER = settings.getDouble("HMbaseMultDestroyer");
            hm_BASE_MULT_CRUISER = settings.getDouble("HMbaseMultCruiser");
            hm_BASE_MULT_CAPITAL = settings.getDouble("HMbaseMultCapital");
            hm_INCR_PER_LEVEL_FRIGATE = settings.getDouble("HMincrPerLevelFrigate");
            hm_INCR_PER_LEVEL_DESTROYER = settings.getDouble("HMincrPerLevelDestroyer");
            hm_INCR_PER_LEVEL_CRUISER = settings.getDouble("HMincrPerLevelCruiser");
            hm_INCR_PER_LEVEL_CAPITAL = settings.getDouble("HMincrPerLevelCapital");
            //
///        SYNERGISTIC THINGS
            both_ODY_AND_ILI_MULT = (float) settings.getDouble("bothOdyAndIliMult");
    }

    public static List<String> RCSW_VanillaFactions = new ArrayList<String>();
//    public static List<String> RCSW_RaiderFactions = new ArrayList<String>();
    
    public void getVanillaFactions() {
        RCSW_VanillaFactions.add("derelict");
        RCSW_VanillaFactions.add("hegemony");
        RCSW_VanillaFactions.add("independent");
        RCSW_VanillaFactions.add("knights_of_ludd");
        RCSW_VanillaFactions.add("lions_guard");
        RCSW_VanillaFactions.add("luddic_church");
        RCSW_VanillaFactions.add("luddic_path");
        RCSW_VanillaFactions.add("neutral");
        RCSW_VanillaFactions.add("persean");
        RCSW_VanillaFactions.add("pirates");
        RCSW_VanillaFactions.add("player");
        RCSW_VanillaFactions.add("poor");
        RCSW_VanillaFactions.add("remnant");
        RCSW_VanillaFactions.add("scavengers");
        RCSW_VanillaFactions.add("sindrian_diktat");
        RCSW_VanillaFactions.add("sleeper");
        RCSW_VanillaFactions.add("tritachyon");
    }
    
    public static List<String> getRaiderFactions() {
        List<String> hiddenMarketFactions = new ArrayList<String>();
        int hiddenMarketCount = 0;
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            hiddenMarketCount = 0;
            for (MarketAPI market : Misc.getFactionMarkets(faction)) {
                if (market.isHidden()) {
                    hiddenMarketCount++;
                }
            }
            if (hiddenMarketCount >= 3) {
                hiddenMarketFactions.add(faction.getId());
            }
        }
        //ALWAYS ADD PIRATES/LP
        if (!hiddenMarketFactions.contains("luddic_path")) {
            hiddenMarketFactions.add("luddic_path");
        }
        if (!hiddenMarketFactions.contains("pirates")) {
            hiddenMarketFactions.add("pirates");
        }
        return hiddenMarketFactions;
    }
    
    public static List<String> getEliteFactions() {
        List<String> zeroMarketsFactions = new ArrayList<String>();
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            if (Misc.getFactionMarkets(faction).isEmpty()) {
                zeroMarketsFactions.add(faction.getId());
            }
        }
        //ALWAYS ADD REDACTED/DERELICTS
        if (!zeroMarketsFactions.contains("remnant")) {
            zeroMarketsFactions.add("remnant");
        }
        if (!zeroMarketsFactions.contains("derelict")) {
            zeroMarketsFactions.add("derelict");
        }
        return zeroMarketsFactions;
    }
    
    public static HashMap<LocationAPI, String> RCSWgetRemnantSystems() {
        HashMap<LocationAPI, String> RCSW_RemnantSystems = new HashMap<LocationAPI, String>();
//        RCSW_RemnantSystems.clear();
/*
        float unitsPerLightYear = Global.getSettings().getFloat("unitsPerLightYear");
        for (SectorEntityToken entity : Global.getSector().getHyperspace().getAllEntities()) {
            if (entity.getMemoryWithoutUpdate().getBoolean(RemnantSystemType.DESTROYED.getBeaconFlag())) {
                RCSW_RemnantSystems.put(Misc.getNearbyStarSystem(entity,0.5f*2000/unitsPerLightYear), "Low");
            }
            if (entity.getMemoryWithoutUpdate().getBoolean(RemnantSystemType.SUPPRESSED.getBeaconFlag())) {
                RCSW_RemnantSystems.put(Misc.getNearbyStarSystem(entity,0.5f*2000/unitsPerLightYear), "Medium");
            }
            if (entity.getMemoryWithoutUpdate().getBoolean(RemnantSystemType.RESURGENT.getBeaconFlag())) {
                RCSW_RemnantSystems.put(Misc.getNearbyStarSystem(entity,0.5f*2000/unitsPerLightYear), "High");
            }
        }
*/
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
           if (system.hasTag("theme_remnant_destroyed") && system.hasTag("theme_remnant_main")) {
               RCSW_RemnantSystems.put((LocationAPI) system, "Low");
           }
           else if (system.hasTag("theme_remnant_suppressed") && system.hasTag("theme_remnant_main")) {
               RCSW_RemnantSystems.put((LocationAPI) system, "Medium");
           }
           else if (system.hasTag("theme_remnant_resurgent") && system.hasTag("theme_remnant_main")) {
               RCSW_RemnantSystems.put((LocationAPI) system, "High");
           }
           else if (system.hasTag("theme_remnant_secondary")) {
               RCSW_RemnantSystems.put((LocationAPI) system, "Secondary");
           }
        }
        return RCSW_RemnantSystems;
    }

    public void RCSWreloadScripts() {
        if (Global.getSector().hasScript(ApplyRCSWChanges.class)) {
            Global.getSector().removeScriptsOfClass(ApplyRCSWChanges.class);
        }
        if (Global.getSector().hasScript(ApplyRCSWChangesTime.class)) {
            Global.getSector().removeScriptsOfClass(ApplyRCSWChangesTime.class);
        }
        if (!Global.getSector().hasScript(ApplyRCSWChanges.class)) {
            Global.getSector().addScript(new ApplyRCSWChanges());
        }
        if (!Global.getSector().hasScript(ApplyRCSWChangesTime.class)) {
            Global.getSector().addScript(new ApplyRCSWChangesTime());
        }
    }
    
    @Override
    public void onApplicationLoad() throws Exception {
        loadRCSWSettings();
        getVanillaFactions();
//        getRaiderFactions();
    }
    
    @Override
    public void onNewGameAfterEconomyLoad() {
	if (SECURE_MARKETS_NEW_GAME) {
            new SecureMarkets().AddMarketDefenses();
        }
        if (ILIAD_MODE) {
            iliTimeUnsafe = 0f;
            Global.getSector().getMemoryWithoutUpdate().set("$timeUnsafe", iliTimeUnsafe);
            if (!ili_DO_NOT_ALERT) {
                iliAlertOnce = true;
            }
        }
    }

    @Override
    public void onGameLoad(boolean newGame) {
        RCSWreloadScripts();
        RCSW_UNINSTALL = false; //Makes sure that the uninstall console command only affects the current save.
        RCSW_RELOAD = true; //Makes sure that loading the game will reload buffs
        if (DOCTRINE_EVOLUTION) {
/*
            for (FactionAPI faction : Global.getSector().getAllFactions()) {
                new DoctrineEvolution().DoctrineReturnToOriginal(faction);
            }               
*/
            new DoctrineEvolution().DoctrineSetup();
            ApplyRCSWChangesTime.deMonthlyIntervalCheck = 31;
            DoctrineEvolution.HighestNumShips = 0;
            
            if (de_ALLOW_AI_FLEET_SIZE_ALERTS) {
                new DoctrineEvolution().AlertToChangeMaxAIShips();
            }
        }
        if (ILIAD_MODE) {
            if (ODYSSEY_MODE) {
                ili_BUFFER_DAYS = ili_BUFFER_DAYS / both_ODY_AND_ILI_MULT;
            }
            if (!ili_DO_NOT_ALERT) {
                iliAlertOnce = true;
            }
            Global.getSector().addTransientListener(new RCSWMarketListener());

            if (!(Global.getSector().getMemoryWithoutUpdate().get("$timeUnsafe") == null)) {
                iliTimeUnsafe = (float) Global.getSector().getMemoryWithoutUpdate().get("$timeUnsafe");
            } else {
                iliTimeUnsafe = 0;
            }
        }
        //hopefully prevents raids from dropping the hullmod.
        if (HULL_MOD) {
            if (!Global.getSector().getPlayerFaction().knowsHullMod("rcsw_secondwave")) {
                Global.getSector().getPlayerFaction().addKnownHullMod("rcsw_secondwave");
            }
        }
        new AdjustedSensors().adjustedSensorsCleanup();
        new AddHullMod().hullModCleanup();
    }
    
    @Override
    public void beforeGameSave() {
        if (ILIAD_MODE) {
            Global.getSector().getMemoryWithoutUpdate().set("$timeUnsafe", iliTimeUnsafe);
        }
        new AdjustedSensors().adjustedSensorsCleanup();
        new AddHullMod().hullModCleanup();
    }
}