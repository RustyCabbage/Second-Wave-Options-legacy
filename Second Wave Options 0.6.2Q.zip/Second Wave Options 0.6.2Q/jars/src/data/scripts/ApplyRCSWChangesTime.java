package data.scripts;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BuffManagerAPI;
import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.RCSecondWavePlugin.*;
import static data.scripts.DoctrineEvolution.DE_LastOverMax;
import static data.scripts.DoctrineEvolution.DE_ONLY_ALERT_ONCE;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;

// THIS ONE DOES NOT RUN WHILE PAUSED

/* TODO:
    -Use EconomyUpdateListener and economyUpdated()?
*/

public class ApplyRCSWChangesTime implements EveryFrameScript {
    public static Logger log = Global.getLogger(ApplyRCSWChanges.class);  
    public static float deMonthlyIntervalCheck = 69f;
    public static float deRemnantUpdateCheck = 0f;  
    SecureMarkets SM = new SecureMarkets();
    DoctrineEvolution DE = new DoctrineEvolution();
    
    @Override
    public void advance(float amount) {
        boolean needsSync = false;
        LocationAPI currentLoc = Global.getSector().getCurrentLocation();
        HashMap<LocationAPI, String> RCSW_RemnantSystems = RCSWgetRemnantSystems();
        float days = Global.getSector().getClock().convertToDays(amount);
        deMonthlyIntervalCheck += days;
                
        if (RCSW_UNINSTALL || RCSW_RELOAD) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {            
                Buff iliBuff = member.getBuffManager().getBuff("iliBuffID");
                if (iliBuff instanceof IliadModeBuff) {
                    member.getBuffManager().removeBuff("iliBuffID");
                    needsSync = true;
                }         
            }
            
            if (needsSync) {
                Global.getSector().getPlayerFleet().forceSync();
            }

            if (RCSW_RELOAD) {   
                RCSW_RELOAD = false;
            } else {
                Global.getSector().removeScript(this);
            }
        } else {

            if (DOCTRINE_EVOLUTION) {
                // Using 30 days instead of convertToMonths in case I want to switch it later
                if (deMonthlyIntervalCheck > 30) {
                    for (FactionAPI faction : Global.getSector().getAllFactions()) {
                        DE.DoctrineReturnToOriginal(faction);
                        log.info("Applying Doctrine Evolution for: "+faction);
                        DE.DoctrineBonusAll(faction);
                        log.info("Adding new technologies for: "+faction);
                        DE.addNewTechnologies(faction);
                    }
                    if (de_ALLOW_AI_FLEET_SIZE_ALERTS) {
                        DE.AlertToChangeMaxAIShips();
                    }
                }

                deRemnantUpdateCheck += days;                
                if (deRemnantUpdateCheck > 0.25) {
                    if (RCSW_RemnantSystems.containsKey(currentLoc)) {
                        for (CampaignFleetAPI localFleet : currentLoc.getFleets()) {
                            if (localFleet.getFaction().getId().equals("remnant") && !localFleet.getName().equals("Nexus")) {
                                boolean manualFPBuffed = false;
                                for (FleetMemberAPI member : localFleet.getFleetData().getMembersListCopy()) {
                                    String buffID = "incrFPBuffID";
                                    float buffDur = 1f;
                                    Buff test = member.getBuffManager().getBuff(buffID);
                                    if (test instanceof IncreaseFleetPointsBuff) {
                                        IncreaseFleetPointsBuff buff = (IncreaseFleetPointsBuff) test;
                                        buff.setDur(buffDur);
                                        manualFPBuffed = true;
                                    } else {
                                        member.getBuffManager().addBuff(new IncreaseFleetPointsBuff(buffID, buffDur));
                                        needsSync = true;
                                    }
                                }
                                if (!manualFPBuffed) {
                                    log.info("Manually updating FP for " + localFleet);
                                    DE.ManualAddRemnantShips(localFleet);
                                }
                            }
                        }
                    }
                    deRemnantUpdateCheck = 0;
                }
            }
            
            if (SECURE_MARKETS_NEW_GAME && sm_ADD_PLANETARY_SHIELD > 0) {
                if (deMonthlyIntervalCheck > 30) {
                    int currentCycle = Global.getSector().getClock().getCycle();
                    int currentMonth = Global.getSector().getClock().getMonth();
                    //add currentMonth == 7 to check twice a year
                    //adds a planetary shield once a year in January if applicable
                    if (currentCycle >= sm_ADD_SHIELD_START_YEAR && currentMonth == 1) {
                        //if set in settings, require the player to have finished the Red Planet quest and unlocked the blueprint first.
                        if (sm_SHIELD_REQUIRE_PLAYER_KNOWN && !Global.getSector().getFaction("player").knowsIndustry("planetaryshield")) {}
                        else {
                            for (FactionAPI faction : Global.getSector().getAllFactions()) {
                                List<MarketAPI> bestMarketList = SM.FindBestMarkets(faction);
                                for (MarketAPI bestMarket : bestMarketList) {
                                    SM.AddPlanetaryShield(bestMarket);
                                }
                            }
                        }
                    }
                }
            }
            
            if (ILIAD_MODE) {
                String buffID = "iliBuffID";
                float buffDur = 1f;
/* used for system-based recovery instead of market based
                iliSafe = false;

                for (MarketAPI market : Misc.getMarketsInLocation(currentLoc)) {
                    if (Math.round(market.getFaction().getRelationship("player")*100) >= ili_MIN_REP) {
                        iliSafe = true;
                        iliTimeUnsafe = 0.0;
                        Global.getSector().getMemoryWithoutUpdate().set("$timeUnsafe", iliTimeUnsafe);
                    }
                }

                if (!iliSafe) {
*/
                iliTimeUnsafe += days;
//                Global.getSector().getMemoryWithoutUpdate().set("$timeUnsafe", iliTimeUnsafe);
//                }
                if (!ili_DO_NOT_ALERT) {
                    if (iliTimeUnsafe > ili_BUFFER_DAYS) {
                        if (iliAlertOnce) {
                            Global.getSector().getCampaignUI().addMessage("Iliad Mode buffer expired: find a friendly market to dock in or your supply and fuel consumption will increase.",Color.YELLOW);
                            iliAlertOnce = false;
                        }
                    } else {
                        iliAlertOnce = true;
                    }
                }
                
                for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
                    BuffManagerAPI.Buff test = member.getBuffManager().getBuff(buffID);
                    if (test instanceof IliadModeBuff) {
                        IliadModeBuff buff = (IliadModeBuff) test;
                        buff.setDur(buffDur);
                        needsSync = true;
                    } else {
                        member.getBuffManager().addBuff(new IliadModeBuff(buffID, buffDur));
                        needsSync = true;
                    }
                }    
            }
            if (needsSync) {
                Global.getSector().getPlayerFleet().forceSync();
            }
            if (deMonthlyIntervalCheck > 30) {
                deMonthlyIntervalCheck = 0;
            }
        }
    }
    
    @Override
     public boolean isDone() {
        return false;
    }
     
    @Override
    public boolean runWhilePaused() {
        return false;
    }
}
