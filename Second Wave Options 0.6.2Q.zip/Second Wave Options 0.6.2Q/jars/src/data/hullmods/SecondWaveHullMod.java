package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

import static data.scripts.RCSecondWavePlugin.hm_BASE_MULT_CAPITAL;
import static data.scripts.RCSecondWavePlugin.hm_BASE_MULT_CRUISER;
import static data.scripts.RCSecondWavePlugin.hm_BASE_MULT_DESTROYER;
import static data.scripts.RCSecondWavePlugin.hm_BASE_MULT_FRIGATE;
import static data.scripts.RCSecondWavePlugin.hm_INCR_PER_LEVEL_CAPITAL;
import static data.scripts.RCSecondWavePlugin.hm_INCR_PER_LEVEL_CRUISER;
import static data.scripts.RCSecondWavePlugin.hm_INCR_PER_LEVEL_DESTROYER;
import static data.scripts.RCSecondWavePlugin.hm_INCR_PER_LEVEL_FRIGATE;
import org.apache.log4j.Logger;


public class SecondWaveHullMod extends BaseHullMod {

//    public static Logger log = Global.getLogger(SecondWaveHullMod.class);
    
    public float roundBetter(float value, int places) {
        if (places < 0) {
            places = 0;
        }        
        float mult = (float) Math.pow(10, places);
        float temp = (float) Math.round(value * mult);
        return temp / mult;
    }
    
    public HashMap<HullSize, Double> getHullModBase() {
        HashMap<HullSize, Double> result = new HashMap<>();
            result.put(HullSize.FRIGATE, hm_BASE_MULT_FRIGATE);
            result.put(HullSize.DESTROYER, hm_BASE_MULT_DESTROYER);
            result.put(HullSize.CRUISER, hm_BASE_MULT_CRUISER);
            result.put(HullSize.CAPITAL_SHIP, hm_BASE_MULT_CAPITAL);
        return result;
    }
    public HashMap<HullSize, Double> getHullModIncr() {
        HashMap<HullSize, Double> result = new HashMap<>();
            result.put(HullSize.FRIGATE, hm_INCR_PER_LEVEL_FRIGATE);
            result.put(HullSize.DESTROYER, hm_INCR_PER_LEVEL_DESTROYER);
            result.put(HullSize.CRUISER, hm_INCR_PER_LEVEL_CRUISER);
            result.put(HullSize.CAPITAL_SHIP, hm_INCR_PER_LEVEL_CAPITAL);
        return result;
    }
    
    
    
/* doesn't work for reasons I don't understand    
    private static Map base = new HashMap();
    static {
        base.put(HullSize.FRIGATE, hm_BASE_MULT_FRIGATE);
        base.put(HullSize.DESTROYER, hm_BASE_MULT_DESTROYER);
        base.put(HullSize.CRUISER, hm_BASE_MULT_CRUISER);
        base.put(HullSize.CAPITAL_SHIP, hm_BASE_MULT_CAPITAL);
    }
    
    //public float incrPerCharLevel = 0.025f;
    private static Map incrPerCharLevel = new HashMap();
    static {
        incrPerCharLevel.put(HullSize.FRIGATE, hm_INCR_PER_LEVEL_FRIGATE);
        incrPerCharLevel.put(HullSize.DESTROYER, hm_INCR_PER_LEVEL_DESTROYER);
        incrPerCharLevel.put(HullSize.CRUISER, hm_INCR_PER_LEVEL_CRUISER);
        incrPerCharLevel.put(HullSize.CAPITAL_SHIP, hm_INCR_PER_LEVEL_CAPITAL);
    }
*/

/*    
    private static Map base = new HashMap();
    static {
        base.put(HullSize.FRIGATE, 1.0f);
        base.put(HullSize.DESTROYER, 0.6f);
        base.put(HullSize.CRUISER, 0.3f);
        base.put(HullSize.CAPITAL_SHIP, 0.1f);
    }
    
    //public float incrPerCharLevel = 0.025f;
    private static Map incrPerCharLevel = new HashMap();
    static {
        incrPerCharLevel.put(HullSize.FRIGATE, 0.025f);
        incrPerCharLevel.put(HullSize.DESTROYER, 0.025f);
        incrPerCharLevel.put(HullSize.CRUISER, 0.02f);
        incrPerCharLevel.put(HullSize.CAPITAL_SHIP, 0.02f);
    }    
*/
    
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        HashMap<HullSize, Double> base = getHullModBase();
        HashMap<HullSize, Double> incrPerCharLevel = getHullModIncr();
        
        float characterLevel = (float) Global.getSector().getPlayerStats().getLevel();
        float baseEffect = base.get(hullSize).floatValue();
        float levelEffect = characterLevel * incrPerCharLevel.get(hullSize).floatValue();
        stats.getDynamic().getMod(Stats.INDIVIDUAL_SHIP_RECOVERY_MOD).modifyMult(id,
                Math.min(1,roundBetter(baseEffect+levelEffect,3)));
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        HashMap<HullSize, Double> base = getHullModBase();
        HashMap<HullSize, Double> incrPerCharLevel = getHullModIncr();
        
        float characterLevel = (float) Global.getSector().getPlayerStats().getLevel();
        if (index == 0) return "" + Math.min(1,roundBetter(base.get(HullSize.FRIGATE).floatValue()+characterLevel*incrPerCharLevel.get(HullSize.FRIGATE).floatValue(),3));
        if (index == 1) return "" + Math.min(1,roundBetter(base.get(HullSize.DESTROYER).floatValue()+characterLevel*incrPerCharLevel.get(HullSize.DESTROYER).floatValue(),3));
        if (index == 2) return "" + Math.min(1,roundBetter(base.get(HullSize.CRUISER).floatValue()+characterLevel*incrPerCharLevel.get(HullSize.CRUISER).floatValue(),3));
        if (index == 3) return "" + Math.min(1,roundBetter(base.get(HullSize.CAPITAL_SHIP).floatValue()+characterLevel*incrPerCharLevel.get(HullSize.CAPITAL_SHIP).floatValue(),3));
        return null;
    }
    
    /* tabled for now because I am lazy
    @Override
    public void addPostDescriptionSection(TooltipMakerAPI tooltip, HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        String message = "";
        if (SLOW_CR) {
            message += "Multiplies CR recovery rate by "+cr_MULT_FRIGATE+"/"+cr_MULT_DESTROYER+"/"+cr_MULT_CRUISER+"/"+cr_MULT_CAPITAL+", depending on hull size.\n";
        }
        if (ODYSSEY_MODE) {
            message += "Increases maintenance cost and fuel use as the fleet moves away from the core.\n";
        }
        if (ILIAD_MODE) {
            message += "Increases maintenance cost and fuel use when the fleet has spent a long time without docking at a hospitable market.\n";
        }
        if (DARK_SECTOR) {
            float strEffect = dark_SHIP_SENSOR_STR_FLAT * dark_SENSOR_SIZE_CHANGE_RANGE;
            float profEffect = dark_SHIP_SENSOR_PRO_FLAT * dark_SENSOR_SIZE_CHANGE_RANGE;
            message += "Increases sensor strength by "+strEffect+"/"+strEffect*2/3+"/"+strEffect*1/3+"/0, depending on hull size.\n";
            message += "Increases sensor profile by 0/"+profEffect*1/3+"/"+profEffect*2/3+"/"+profEffect+", depending on hull size.\n";
        }
        tooltip.addPara(message, 10f);
    }
    */
}



