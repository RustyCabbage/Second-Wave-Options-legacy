package data.scripts;

import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.RCSecondWavePlugin.dark_SHIP_SENSOR_STR_FLAT;
import static data.scripts.RCSecondWavePlugin.dark_SHIP_SENSOR_PRO_FLAT;
import static data.scripts.RCSecondWavePlugin.dark_SENSOR_SIZE_CHANGE_RANGE;
        
public class DarkSectorBuff implements Buff {
    private final String id;
    private float dur;
    
    public DarkSectorBuff(String id, float dur) {
        this.id = id;
        this.dur = dur;
    }    
    
    private float strEffect = dark_SHIP_SENSOR_STR_FLAT * dark_SENSOR_SIZE_CHANGE_RANGE;
    private float profEffect = dark_SHIP_SENSOR_PRO_FLAT * dark_SENSOR_SIZE_CHANGE_RANGE;
    
    @Override
    public void apply(FleetMemberAPI member) {
        if (!member.getStats().getSensorStrength().getFlatMods().containsKey(id)) {
            if (member.isFrigate()) {
                member.getStats().getSensorStrength().modifyFlat(id, strEffect, "Dark Sector");
            }
            else if (member.isDestroyer()) {
                member.getStats().getSensorStrength().modifyFlat(id, strEffect * 2/3, "Dark Sector");
            }
            else if (member.isCruiser()) {
                member.getStats().getSensorStrength().modifyFlat(id, strEffect * 1/3, "Dark Sector");
            }
//            else if (member.isCapital()) {
//                member.getStats().getSensorStrength().modifyFlat(id, dark_SHIP_SENSOR_STR_FLAT * dark_SENSOR_SIZE_CHANGE_RANGE, "Dark Sector");
//            }
        }        
        if (!member.getStats().getSensorProfile().getFlatMods().containsKey(id)) {
//            if (member.isFrigate()) {
//                member.getStats().getSensorProfile().modifyFlat(id, dark_SHIP_SENSOR_PRO_FLAT * dark_SENSOR_SIZE_CHANGE_RANGE, "Dark Sector");
//            } else
            if (member.isDestroyer()) {
                member.getStats().getSensorProfile().modifyFlat(id, profEffect * 1/3, "Dark Sector");
            }
            else if (member.isCruiser()) {
                member.getStats().getSensorProfile().modifyFlat(id, profEffect * 2/3, "Dark Sector");
            }
            else if (member.isCapital()) {
                member.getStats().getSensorProfile().modifyFlat(id, profEffect, "Dark Sector");
            }
        }
    }

    @Override
    public String getId() {
        return id;
    }
    @Override
    public boolean isExpired() {
        return dur <= 0;
    }

    public float getDur() {
        return dur;
    }
    
    public void setDur(float dur) {
        this.dur = dur;
    }
    
    @Override
    public void advance(float days) {
        setDur(dur);
    }
}