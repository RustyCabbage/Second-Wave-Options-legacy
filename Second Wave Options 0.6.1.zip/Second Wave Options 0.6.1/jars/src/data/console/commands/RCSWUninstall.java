package data.console.commands;

import com.fs.starfarer.api.Global;
import data.scripts.ApplyRCSWChanges;
import data.scripts.RCSecondWavePlugin;
import org.lazywizard.console.Console;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;

public class RCSWUninstall implements BaseCommand {
    
    //FULL UNINSTALLATION DOESN'T WORK ANYMORE
    //SO I DON'T THINK THIS COMMAND IS NEEDED
    
    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
        
        if (Global.getSector().hasScript(ApplyRCSWChanges.class)) {
            RCSecondWavePlugin.RCSW_UNINSTALL = true;    
            Console.showMessage("RC's Second Wave Options uninstalled. Most changes should be removed immediately - you may continue playing.");
            //Console.showMessage("CAUTION: You will need to reuse this command if you reload this save with the mod still enabled.");
            return CommandResult.SUCCESS;
        } else {
            Console.showMessage("RC's Second Wave Options is currently not active.");
            return CommandResult.WRONG_CONTEXT;
        }
    }
}
