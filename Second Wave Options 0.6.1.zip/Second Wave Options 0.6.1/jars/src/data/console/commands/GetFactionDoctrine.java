package data.console.commands;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FactionDoctrineAPI;
import java.util.ArrayList;
import java.util.List;
import org.lazywizard.console.Console;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;

public class GetFactionDoctrine implements BaseCommand {
    
    @Override
    public BaseCommand.CommandResult runCommand(String args, BaseCommand.CommandContext context) {
        List<String> ids;
        ids = new ArrayList<String>();
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            ids.add(faction.getId());
        }
        
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }
        
        if ("vanilla".equals(args)) {
            List<String> vanillaFactions = new ArrayList<String>();
                vanillaFactions.add("hegemony");
                vanillaFactions.add("persean");
                vanillaFactions.add("luddic_church");
                vanillaFactions.add("sindrian_diktat");
                vanillaFactions.add("tritachyon");
                vanillaFactions.add("independent");
                vanillaFactions.add("pirates");
                vanillaFactions.add("luddic_path");
                vanillaFactions.add("derelict");
                vanillaFactions.add("remnant");
                
            for (String factionID : vanillaFactions) {
                FactionAPI faction = Global.getSector().getFaction(factionID);
                FactionDoctrineAPI doctrine = faction.getDoctrine();
                Console.showMessage("For faction '"+faction+"':");
                Console.showMessage("The Officer Quality level is: "+doctrine.getOfficerQuality());
                Console.showMessage("The Ship Quality level is: "+doctrine.getShipQuality());
                Console.showMessage("The Ship Quantity level is :"+doctrine.getNumShips());
                Console.showMessage("The Aggression level is: "+doctrine.getAggression());
                Console.showMessage("The Ship Size is: "+doctrine.getShipSize());
                Console.showMessage("The autofit randomize probability is: "+doctrine.getAutofitRandomizeProbability());
                Console.showMessage("The faction's total strength points is: "+doctrine.getTotalStrengthPoints());
                Console.showMessage("--------------------------------------");
            }
            return CommandResult.SUCCESS;
        }    
        
        else if (!ids.contains(args)) {
//            Console.showMessage("Faction not recognized or is not in this game.");
            return CommandResult.BAD_SYNTAX;
        }
        
        FactionDoctrineAPI doctrine = Global.getSector().getFaction(args).getDoctrine();
        Console.showMessage("For faction '"+args+"':");
        Console.showMessage("The Officer Quality level is: "+doctrine.getOfficerQuality());
        Console.showMessage("The Ship Quality level is: "+doctrine.getShipQuality());
        Console.showMessage("The Ship Quantity level is :"+doctrine.getNumShips());
        Console.showMessage("The Aggression level is: "+doctrine.getAggression());
        Console.showMessage("The Ship Size is: "+doctrine.getShipSize());
        Console.showMessage("The autofit randomize probability is: "+doctrine.getAutofitRandomizeProbability());
        Console.showMessage("The faction's total strength points is: "+doctrine.getTotalStrengthPoints());
        Console.showMessage("--------------------------------------");
        //Not sure what this does
        //Console.showMessage("getFleets(): "+doctrine.getFleets());
        return CommandResult.SUCCESS;
    }
}
